import cv2
import numpy as np

img = cv2.imread('/home/max/job/labelme/labelme/maple-leaves.png', cv2.IMREAD_UNCHANGED)

img = cv2.resize(img,(32,32))
cv2.imwrite('/home/max/job/labelme/labelme/maple32.png', img)

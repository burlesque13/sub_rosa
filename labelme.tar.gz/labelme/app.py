# -*- coding: utf-8 -*-
import functools
import io
import os
import os.path as osp
import re
import webbrowser
import numpy as np
import cv2
import glob
import qimage2ndarray
from random import randint, choice
import math

import matplotlib.pyplot as plt
import PIL.Image

from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot, QTimer, QMutex
from qtpy.QtCore import Qt
from qtpy import QtGui, QtWidgets, QtCore

from labelme import __appname__
from labelme import PY2
from labelme import QT5
from labelme.utils.pascal_voc_io import PascalVocReader, PascalVocWriter
from labelme.utils.labelFile import LabelFile, LabelFileError

from labelme.config import get_config
from labelme.label_file import LabelFile
from labelme.label_file import LabelFileError
from labelme import logger
from labelme.shape import DEFAULT_FILL_COLOR
from labelme.shape import DEFAULT_LINE_COLOR
from labelme.shape import Shape
from labelme.utils import addActions
from labelme.utils import fmtShortcut
from labelme.utils import newAction
from labelme.utils import newIcon
from labelme.utils import struct
from labelme.widgets import Canvas
from labelme.widgets import ColorDialog
from labelme.widgets import EscapableQListWidget
from labelme.widgets import LabelDialog
from labelme.widgets import LabelQListWidget
from labelme.widgets import ToolBar
from labelme.widgets import ZoomWidget


FORMAT_PASCALVOC='PascalVOC'
FORMAT_YOLO='YOLO'
TXT_EXT = '.txt'
XML_EXT = '.xml'

class GenericWorker(QObject):
    def __init__(self, function, *args, **kwargs):
        super(GenericWorker, self).__init__()

        self.function = function
        self.args = args
        self.kwargs = kwargs
        self.start.connect(self.run)
        self.mutex = QMutex()

    start = pyqtSignal(str)
    finished = pyqtSignal(str)
    value_changed = pyqtSignal(int)

    @pyqtSlot(str)
    def run(self, some_string_arg):
        self.function(*self.args, **self.kwargs)
        self.finished.emit("hello")

class Second(QtWidgets.QDialog,QtWidgets.QProgressBar):
    def __init__(self, parent=None):
        super(Second, self).__init__(parent)

        self.setWindowTitle("Progress Bar")
        self.setFixedSize(520,120)
        self.setWindowFlags(Qt.SplashScreen)
        myFont = QtGui.QFont()
        myFont.setBold(True)
        myFont.setStyle(QtGui.QFont.StyleOblique)
        myFont.setPixelSize(15)

        self.timer = QTimer()
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.local_timer_handler)

        self.text_hint = QtWidgets.QLabel("Data is being generated")
        self.text_hint.setFont(myFont)
        self.text_hint.setAlignment(QtCore.Qt.AlignCenter)
        self.text_hint.setFixedWidth(502)

        self.close_button = QtWidgets.QPushButton()
        self.close_button.setText("Close")
        self.close_button.setFixedWidth(220)
        self.close_button.setVisible(True)

        self.stop_button = QtWidgets.QPushButton()
        self.stop_button.setText("Stop")
        self.stop_button.setFixedWidth(220)
        self.stop_button.setVisible(True)
        self.stop_button.clicked.connect(self.stop_button_clicked)

        self.progress_bar = QtWidgets.QProgressBar(self)
        self.progress_bar.setVisible(True)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFixedWidth(502)
        self.progress_bar.setAlignment(QtCore.Qt.AlignHCenter)
        self.progress_bar.setRange(0,100)
        self.progress_bar.setValue(0)

        self.dialog_GLO = QtWidgets.QGridLayout()
        self.dialog_GLO.addWidget(self.text_hint,0,0)
        self.dialog_GLO.addWidget(self.progress_bar,1,0)
        self.dialog_GLO.addWidget(self.close_button,2,0)
        self.dialog_GLO.setHorizontalSpacing(10)
        self.dialog_GLO.setVerticalSpacing(20)
        self.dialog_GLO.addWidget(self.stop_button,2,1)
        self.dialog_GLO.setAlignment(QtCore.Qt.AlignLeft)

        self.setLayout(self.dialog_GLO)

    def keyPressEvent(self, event):
        if type(event) == QtGui.QKeyEvent:
            if event.key() == QtCore.Qt.Key_Escape: pass

    def stop_button_clicked(self):
        self.stop_button.setEnabled(False)

    def closeEvent(self, *args, **kwargs):
        self.stop_button.setEnabled(True)
        self.stop_button.setText("Stop")
        self.progress_bar.reset()
        self.timer.stop()

    def showEvent(self, *args, **kwargs):
        self.text_hint.setText("Data is being generated")
        self.timer.start(1000)

    def local_timer_handler(self):
        if str(self.text_hint.text())[-3] == ".":
            self.text_hint.setText("Data is being generated")
        else:
            self.text_hint.setText(self.text_hint.text() + '.')


class WindowMixin(object):
    def menu(self, title, actions=None):
        menu = self.menuBar().addMenu(title)
        if actions:
            addActions(menu, actions)
        return menu

    def toolbar(self, title, actions=None):
        toolbar = ToolBar(title)
        toolbar.setObjectName('%sToolBar' % title)
        toolbar.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        toolbar.setFloatable(False)
        toolbar.setMovable(False)
        toolbar.setAllowedAreas(Qt.TopToolBarArea)
        if actions:
            addActions(toolbar, actions)
        self.addToolBar(Qt.TopToolBarArea, toolbar)
        return toolbar

class MainWindow(QtWidgets.QMainWindow, WindowMixin,QObject):
    FIT_WINDOW, FIT_WIDTH, MANUAL_ZOOM = 0, 1, 2

    def __init__(
        self,
        config=None,
        filename=None,
        output=None,
        output_file=None,
        output_dir=None,
    ):
        self.arr = []
        self.directions = []
        self.tmp_picture = None
        self.bool_selection_changed = True
        self.pictures_total = 0
        self.pictures_iter = 0

        self.samples_iter = 0
        self.samples_total = 0

        self.usingPascalVocFormat = True
        self.usingYoloFormat = False

        self.signs_dir = None
        self.dataset_dir = None
        self.flag = False

        self.timer_singleshot = QTimer()
        self.timer_singleshot.setSingleShot(True)
        self.timer_singleshot.timeout.connect(self.thread_cleanup)

        self.timer_preview_color = QTimer()
        self.timer_preview_color.setSingleShot(True)
        self.timer_preview_color.timeout.connect(self.preview_button_color)

        self.signs_flag = False
        self.samples_flag = False
        self.preview_flag = False
        self.usual_mode_flag = False

        self.picture_dict = {}

        if output is not None:
            logger.warning(
                'argument output is deprecated, use output_file instead'
            )
            if output_file is None:
                output_file = output

        # see labelme/config/default_config.yaml for valid configuration
        if config is None:
            config = get_config()
        self._config = config

        super(MainWindow, self).__init__()
        self.setWindowTitle(__appname__)

        self.dialog = Second(self)
        self.dialog.setModal(True)
        self.dialog.close_button.clicked.connect(self.close_button_handler)
        self.dialog.stop_button.clicked.connect(self.stop_button_handler)
        # Whether we need to save or not.
        self.dirty = False
        self._noSelectionSlot = False
        # Main widgets and related state.
        self.labelDialog = LabelDialog(
            parent=self,
            labels=self._config['labels'],
            sort_labels=self._config['sort_labels'],
            show_text_field=self._config['show_label_text_field'],
            completion=self._config['label_completion'],
            fit_to_content=self._config['fit_to_content'],
        )

        self.labelList = LabelQListWidget()
        self.lastOpenDir = None

        self.flag_dock = self.flag_widget = None
        self.flag_dock = QtWidgets.QDockWidget('Flags', self)
        self.flag_dock.setObjectName('Flags')
        self.flag_widget = QtWidgets.QListWidget()
        if config['flags']:
            self.loadFlags({k: False for k in config['flags']})
        self.flag_dock.setWidget(self.flag_widget)
        self.flag_widget.itemChanged.connect(self.setDirty)

        self.labelList.itemActivated.connect(self.labelSelectionChanged)
        self.labelList.itemSelectionChanged.connect(self.labelSelectionChanged)
        self.labelList.itemDoubleClicked.connect(self.editLabel)
        # Connect to itemChanged to detect checkbox changes.
        self.labelList.itemChanged.connect(self.labelItemChanged)
        self.labelList.setDragDropMode(
            QtWidgets.QAbstractItemView.InternalMove)
        self.labelList.setParent(self)
        self.shape_dock = QtWidgets.QDockWidget('Polygon Labels', self)
        self.shape_dock.setObjectName('Labels')
        self.shape_dock.setWidget(self.labelList)

        self.uniqLabelList = EscapableQListWidget()
        self.uniqLabelList.setToolTip(
            "Select label to start annotating for it. "
            "Press 'Esc' to deselect.")
        if self._config['labels']:
            self.uniqLabelList.addItems(self._config['labels'])
            self.uniqLabelList.sortItems()
        self.label_dock = QtWidgets.QDockWidget(u'Label List', self)
        self.label_dock.setObjectName(u'Label List')
        self.label_dock.setWidget(self.uniqLabelList)

        self.fileSearch = QtWidgets.QLineEdit()
        self.fileSearch.setPlaceholderText('Search Filename')
        self.fileSearch.textChanged.connect(self.fileSearchChanged)

        myFont = QtGui.QFont()
        myFont.setBold(True)
        myFont.setCapitalization(True)

        self.settings_label = QtWidgets.QLabel("Settings")
        self.settings_label.setFont(myFont)

        self.total_pictures_to_generate = QtWidgets.QLabel()
        self.total_pictures_to_generate.setAlignment(QtCore.Qt.AlignRight)

        self.fileListWidget = QtWidgets.QListWidget()
        self.fileListWidget.itemSelectionChanged.connect(self.fileSelectionChanged)
        fileListLayout = QtWidgets.QVBoxLayout()
        fileListLayout.setContentsMargins(0, 0, 0, 0)
        fileListLayout.setSpacing(0)
        fileListLayout.addWidget(self.fileSearch)
        fileListLayout.addWidget(self.fileListWidget)

        self.file_dock = QtWidgets.QDockWidget(u'Original File List', self)
        self.file_dock.setObjectName(u'Files')
        self.file_dock.setFixedWidth(460)
        self.file_dock.setVisible(True)
        fileListWidget = QtWidgets.QWidget()
        fileListWidget.setLayout(fileListLayout)
        self.file_dock.setWidget(fileListWidget)

        self.fileSearchP = QtWidgets.QLineEdit()
        self.fileSearchP.setPlaceholderText('Search Filename')
        self.fileSearchP.textChanged.connect(self.fileSearchChanged)

        self.fileListWidgetP = QtWidgets.QListWidget()
        self.fileListWidgetP.itemSelectionChanged.connect(self.processedFilesSelectionChanged)
        fileListLayoutP = QtWidgets.QVBoxLayout()
        fileListLayoutP.setContentsMargins(0, 0, 0, 0)
        fileListLayoutP.setSpacing(0)
        fileListLayoutP.addWidget(self.fileSearchP)
        fileListLayoutP.addWidget(self.fileListWidgetP)
        self.file_dockP = QtWidgets.QDockWidget(u'Procceced File List', self)
        self.file_dockP.setObjectName(u'PFiles')
        fileListWidgetP = QtWidgets.QWidget()
        fileListWidgetP.setLayout(fileListLayoutP)
        self.file_dockP.setWidget(fileListWidgetP)

        self.other_effects = QtWidgets.QLabel()
        self.other_effects.setText("other effects\n")
        self.other_effects.setFont(myFont)

        self.noized = QtWidgets.QLabel()
        self.noized.setText("Noized")
        self.noized.setEnabled(False)

        self.noized_chb = QtWidgets.QCheckBox()
        self.noized_chb.setToolTip("Enabled")

        self.flared = QtWidgets.QLabel()
        self.flared.setText("Flared")
        self.flared.setEnabled(False)

        self.flared_chb = QtWidgets.QCheckBox()
        self.flared_chb.setToolTip("Enabled")

        self.distortion_direction = QtWidgets.QLabel()
        self.distortion_direction.setText("3D transformation\n")
        self.distortion_direction.setFont(myFont)

        self.l_dist = QtWidgets.QLabel()
        self.l_dist.setText("Left Perspective\t")
        self.l_dist.setEnabled(False)

        self.l_dist_chb = QtWidgets.QCheckBox()
        self.l_dist_chb.setToolTip("Enabled")

        self.r_dist = QtWidgets.QLabel()
        self.r_dist.setText("Right Perspective\t")
        self.r_dist.setEnabled(False)

        self.r_dist_chb = QtWidgets.QCheckBox()
        self.r_dist_chb.setToolTip("Enabled")

        self.b_dist = QtWidgets.QLabel()
        self.b_dist.setText("Bot Perspective\t")
        self.b_dist.setEnabled(False)

        self.b_dist_chb = QtWidgets.QCheckBox()
        self.b_dist_chb.setToolTip("Enabled")

        self.r_dist_slider = QtWidgets.QSlider(Qt.Horizontal)
        self.r_dist_slider.setTickInterval(1)
        self.r_dist_slider.setRange(0,10)
        self.r_dist_slider.setTickPosition(QtWidgets.QSlider.NoTicks)

        self.r_dist_spin = QtWidgets.QSpinBox()
        self.r_dist_spin = QtWidgets.QSpinBox()
        self.r_dist_spin.setRange(0,10)
        self.r_dist_spin.setSingleStep(1)
        self.r_dist_spin.setFixedWidth(50)

        self.l_dist_slider = QtWidgets.QSlider(Qt.Horizontal)
        self.l_dist_slider.setTickInterval(1)
        self.l_dist_slider.setRange(0,10)
        self.l_dist_slider.setTickPosition(QtWidgets.QSlider.NoTicks)

        self.l_dist_spin = QtWidgets.QSpinBox()
        self.l_dist_spin.setRange(0,10)
        self.l_dist_spin.setSingleStep(1)
        self.l_dist_spin.setFixedWidth(50)

        self.b_dist_slider = QtWidgets.QSlider(Qt.Horizontal)
        self.b_dist_slider.setTickInterval(1)
        self.b_dist_slider.setRange(0,10)
        self.b_dist_slider.setTickPosition(QtWidgets.QSlider.NoTicks)

        self.b_dist_spin = QtWidgets.QSpinBox()
        self.b_dist_spin.setRange(0,10)
        self.b_dist_spin.setSingleStep(1)
        self.b_dist_spin.setFixedWidth(50)

        self.r_dist_slider.setEnabled(False)
        self.l_dist_slider.setEnabled(False)
        self.b_dist_slider.setEnabled(False)

        self.r_dist_spin.setEnabled(False)
        self.l_dist_spin.setEnabled(False)
        self.b_dist_spin.setEnabled(False)

        self.l_dist_slider.valueChanged.connect(lambda: self.l_dist_spin.setValue(self.l_dist_slider.value()))
        self.l_dist_spin.valueChanged.connect(lambda: self.l_dist_slider.setValue(self.l_dist_spin.value()))

        self.r_dist_slider.valueChanged.connect(lambda: self.r_dist_spin.setValue(self.r_dist_slider.value()))
        self.r_dist_spin.valueChanged.connect(lambda: self.r_dist_slider.setValue(self.r_dist_spin.value()))

        self.b_dist_slider.valueChanged.connect(lambda: self.b_dist_spin.setValue(self.b_dist_slider.value()))
        self.b_dist_spin.valueChanged.connect(lambda: self.b_dist_slider.setValue(self.b_dist_spin.value()))

        self.img_size = QtWidgets.QLabel()
        self.img_size.setText("Image size px\n")
        self.img_size.setFont(myFont)

        self.min_size = QtWidgets.QLabel()
        self.min_size.setText("Min\t")
        self.min_size.setEnabled(False)
        self.min_size_chb = QtWidgets.QCheckBox()
        self.min_size_chb.setToolTip("Enabled")
        self.min_size_spin = QtWidgets.QSpinBox()
        self.min_size_spin.setValue(16)
        self.min_size_spin.setRange(16,114)
        self.min_size_spin.setSingleStep(1)
        self.min_size_spin.setSuffix("px")
        self.min_size_spin.setFixedWidth(100)
        self.min_size_spin.setEnabled(False)

        self.max_size = QtWidgets.QLabel()
        self.max_size.setText("Max\t")
        self.max_size.setEnabled(False)
        self.max_size_chb = QtWidgets.QCheckBox()
        self.max_size_chb.setToolTip("Enabled")
        self.max_size_spin = QtWidgets.QSpinBox()
        self.max_size_spin.setValue(16)
        self.max_size_spin.setRange(16,300)
        self.max_size_spin.setSingleStep(1)
        self.max_size_spin.setSuffix("px")
        self.max_size_spin.setFixedWidth(100)
        self.max_size_spin.setEnabled(False)

        self.step_size = QtWidgets.QLabel()
        self.step_size.setText("   Step\t")
        self.step_size.setEnabled(False)
        self.step_size_spin = QtWidgets.QSpinBox()
        self.step_size_spin.setValue(1)
        self.step_size_spin.setSingleStep(1)
        self.step_size_spin.setPrefix("")
        self.step_size_spin.setSuffix("px")
        self.step_size_spin.setEnabled(False)
        self.step_size_spin.setFixedWidth(100)

        self.rotate_angl = QtWidgets.QLabel()
        self.rotate_angl.setText("Rotation angles\n")
        self.rotate_angl.setFont(myFont)

        self.min_angle = QtWidgets.QLabel()
        self.min_angle.setText("Min\t")
        self.min_angle.setEnabled(False)
        self.min_angle_chb = QtWidgets.QCheckBox()
        self.min_angle_chb.setToolTip("Enabled")
        self.min_angle_spin = QtWidgets.QSpinBox()
        self.min_angle_spin.setValue(0)
        self.min_angle_spin.setRange(0,35)
        self.min_angle_spin.setSingleStep(1)
        self.min_angle_spin.setPrefix("-")
        self.min_angle_spin.setSuffix("°")
        self.min_angle_spin.setEnabled(False)
        self.min_angle_spin.setFixedWidth(100)

        self.max_angle = QtWidgets.QLabel()
        self.max_angle.setText("Max\t")
        self.max_angle.setEnabled(False)
        self.max_angle_chb = QtWidgets.QCheckBox()
        self.max_angle_chb.setToolTip("Enabled")
        self.max_angle_spin = QtWidgets.QSpinBox()
        self.max_angle_spin.setValue(0)
        self.max_angle_spin.setRange(0,35)
        self.max_angle_spin.setSingleStep(1)
        self.max_angle_spin.setPrefix("+")
        self.max_angle_spin.setSuffix("°")
        self.max_angle_spin.setEnabled(False)
        self.max_angle_spin.setFixedWidth(100)

        self.step_angle = QtWidgets.QLabel()
        self.step_angle.setText("   Step\t")
        self.step_angle.setEnabled(False)
        self.step_angle_spin = QtWidgets.QSpinBox()
        self.step_angle_spin.setValue(1)
        self.step_angle_spin.setSingleStep(1)
        self.step_angle_spin.setPrefix("")
        self.step_angle_spin.setSuffix("°")
        self.step_angle_spin.setEnabled(False)
        self.step_angle_spin.setFixedWidth(100)

        self.generate_button = QtWidgets.QPushButton()
        self.generate_button.setText("\tGenerate")
        self.generate_button.setEnabled(False)

        self.preview_button = QtWidgets.QPushButton()
        self.preview_button.setText("\tPreview")
        self.preview_button.setCheckable(True)
        self.preview_button.setStyleSheet("color: black;")

        self.generate_button.clicked.connect(self.generate_button_method)
        self.preview_button.clicked.connect(self.preview_button_method)

        self.kernel = QtWidgets.QLabel()
        self.kernel.setText("Kernel size\t")
        self.kernel.setEnabled(False)
        self.kernel_chb = QtWidgets.QCheckBox()
        self.kernel_chb.setToolTip("Enabled")
        self.k_size_slider = QtWidgets.QSlider(Qt.Horizontal)
        self.k_size_slider.setRange(1,11)
        self.k_size_slider.setTickInterval(2)
        self.k_size_slider.setTickPosition(QtWidgets.QSlider.NoTicks)
        self.k_size_slider.setEnabled(False)
        self.kernel_size_spin = QtWidgets.QSpinBox()
        self.kernel_size_spin.setValue(1)
        self.kernel_size_spin.setRange(1,11)
        self.kernel_size_spin.setSingleStep(2)
        self.kernel_size_spin.setFixedWidth(50)
        self.kernel_size_spin.setEnabled(False)

        self.contrast = QtWidgets.QLabel()
        self.contrast.setText("Contrast\t\t")
        self.contrast.setEnabled(False)
        self.contrast_chb = QtWidgets.QCheckBox()
        self.contrast_chb.setToolTip("Enabled")
        self.contrast_slider = QtWidgets.QSlider(Qt.Horizontal)
        self.contrast_slider.setTickInterval(1)
        self.contrast_slider.setRange(0,100)
        self.contrast_slider.setTickPosition(QtWidgets.QSlider.NoTicks)
        self.contrast_slider.setEnabled(False)
        self.contrast_spin = QtWidgets.QSpinBox()
        self.contrast_spin.setRange(0,100)
        self.contrast_spin.setSingleStep(1)
        self.contrast_spin.setEnabled(False)

        self.texture_transformations = QtWidgets.QLabel()
        self.texture_transformations.setText("texture transformations\n")
        self.texture_transformations.setFont(myFont)

        self.brightness = QtWidgets.QLabel()
        self.brightness.setText("Brightness\t")
        self.brightness.setEnabled(False)
        self.brightness_chb = QtWidgets.QCheckBox()
        self.brightness_chb.setToolTip("Enabled")
        self.brightness_slider = QtWidgets.QSlider(Qt.Horizontal)
        self.brightness_slider.setTickInterval(20)
        self.brightness_slider.setSingleStep(20)
        self.brightness_slider.setRange(0,100)
        self.brightness_slider.setTickPosition(QtWidgets.QSlider.NoTicks)
        self.brightness_slider.setEnabled(False)
        self.brightness_spin = QtWidgets.QSpinBox()
        self.brightness_spin.setRange(0,100)
        self.brightness_spin.setSingleStep(20)
        self.brightness_spin.setEnabled(False)

        '''3D TRANSFORMATION'''
        self.l_dist_chb.toggled.connect(self.left_perspective)
        self.l_dist_chb.toggled.connect(self.generate_button_check_enabled)
        self.l_dist_chb.toggled.connect(lambda: self.realtime_preview(action='3d',dir='l'))
        self.l_dist_spin.valueChanged.connect(lambda: self.realtime_preview(action='3d',dir='l'))

        self.r_dist_chb.toggled.connect(self.right_perspective)
        self.r_dist_chb.toggled.connect(self.generate_button_check_enabled)
        self.r_dist_chb.toggled.connect(lambda: self.realtime_preview(action='3d',dir='r'))
        self.r_dist_spin.valueChanged.connect(lambda: self.realtime_preview(action='3d',dir='r'))

        self.b_dist_chb.toggled.connect(self.bottom_perspective)
        self.b_dist_chb.toggled.connect(self.generate_button_check_enabled)
        self.b_dist_chb.toggled.connect(lambda: self.realtime_preview(action='3d',dir='b'))
        self.b_dist_spin.valueChanged.connect(lambda: self.realtime_preview(action='3d',dir='b'))

        '''ROTATION ANGLES'''
        self.min_angle_chb.toggled.connect(self.min_angle_chb_toggled)
        self.min_angle_chb.toggled.connect(self.generate_button_check_enabled)
        self.min_angle_chb.toggled.connect(lambda: self.realtime_preview(action='rotate',angle=self.min_angle_spin.value().__neg__()))
        self.min_angle_spin.valueChanged.connect(lambda: self.realtime_preview(action='rotate',angle=self.min_angle_spin.value().__neg__()))

        self.max_angle_chb.toggled.connect(self.max_angle_chb_toggled)
        self.max_angle_chb.toggled.connect(self.generate_button_check_enabled)
        self.max_angle_chb.toggled.connect(lambda: self.realtime_preview(action='rotate',angle=self.max_angle_spin.value()))
        self.max_angle_spin.valueChanged.connect(lambda: self.realtime_preview(action='rotate',angle=self.max_angle_spin.value()))

        self.step_angle_spin.valueChanged.connect(self.calculate_pict_among)
        self.step_angle_spin.valueChanged.connect(self.step_angle_editining_finished)


        '''IMAGE SIZE PX'''
        self.min_size_chb.toggled.connect(self.min_size_chb_toggled)
        self.min_size_chb.toggled.connect(self.generate_button_check_enabled)
        self.min_size_chb.toggled.connect(lambda: self.realtime_preview(action='resize',px=self.min_size_spin.value()))
        self.min_size_spin.valueChanged.connect(self.min_size_editing_finished)
        self.min_size_spin.valueChanged.connect(lambda: self.realtime_preview(action='resize',px=self.min_size_spin.value()))

        self.max_size_chb.toggled.connect(self.max_size_chb_toggled)
        self.max_size_chb.toggled.connect(self.generate_button_check_enabled)
        self.max_size_chb.toggled.connect(lambda: self.realtime_preview(action='resize',px=self.max_size_spin.value()))
        self.max_size_spin.valueChanged.connect(self.max_size_editing_finished)
        self.max_size_spin.valueChanged.connect(lambda: self.realtime_preview(action='resize',px=self.max_size_spin.value()))

        self.step_size_spin.valueChanged.connect(self.calculate_pict_among)
        self.step_size_spin.valueChanged.connect(self.step_size_editining_finished)


        '''TEXTURE TRANSFORMATIONS'''
        self.brightness_chb.toggled.connect(self.generate_button_check_enabled)
        self.brightness_chb.toggled.connect(self.brightness_chb_toggled)
        self.brightness_chb.toggled.connect(lambda: self.realtime_preview(action='bright'))
        self.brightness_spin.valueChanged.connect(lambda: self.realtime_preview(action='bright'))
        self.brightness_slider.valueChanged.connect(lambda: self.brightness_spin.setValue(self.brightness_slider.value()))
        self.brightness_spin.valueChanged.connect(lambda: self.brightness_slider.setValue(self.brightness_spin.value()))

        self.contrast_chb.toggled.connect(self.contrast_chb_toggled)
        self.contrast_chb.toggled.connect(self.generate_button_check_enabled)
        self.contrast_chb.toggled.connect(lambda: self.realtime_preview(action='contrast'))
        self.contrast_spin.valueChanged.connect(lambda: self.realtime_preview(action='contrast'))
        self.contrast_slider.valueChanged.connect(lambda: self.contrast_spin.setValue(self.contrast_slider.value()))
        self.contrast_spin.valueChanged.connect(lambda: self.contrast_slider.setValue(self.contrast_spin.value()))

        self.kernel_chb.toggled.connect(self.kernel_chb_toggled)
        self.kernel_chb.toggled.connect(self.generate_button_check_enabled)
        self.kernel_chb.toggled.connect(lambda: self.realtime_preview(action='blur'))
        self.kernel_size_spin.valueChanged.connect(lambda: self.realtime_preview(action='blur'))
        self.k_size_slider.valueChanged.connect(lambda: self.kernel_size_spin.setValue(self.k_size_slider.value()))
        self.kernel_size_spin.valueChanged.connect(lambda: self.k_size_slider.setValue(self.kernel_size_spin.value()))

        '''OTHER EFFECTS'''
        self.noized_chb.toggled.connect(self.generate_button_check_enabled)
        self.noized_chb.toggled.connect(lambda: self.realtime_preview(action='noized'))

        self.flared_chb.toggled.connect(self.generate_button_check_enabled)
        self.flared_chb.toggled.connect(lambda: self.realtime_preview(action='flared'))

        self.groupBox = QtWidgets.QGroupBox()
        self.groupBox.setFixedWidth(450)
        self.groupBox.setVisible(False)
        fileListLayout.addWidget(self.groupBox)

        self.gb1 = QtWidgets.QGroupBox()

        vertLayOut = QtWidgets.QVBoxLayout()
        kernelVLayOut = QtWidgets.QVBoxLayout()

        distortionVLayOut = QtWidgets.QVBoxLayout()
        distortionVLayOut.setSpacing(10)

        angleVLayOut = QtWidgets.QVBoxLayout()
        angleVLayOut.setSpacing(10)

        sizeVLayOut = QtWidgets.QVBoxLayout()
        sizeVLayOut.setSpacing(10)

        brCnKsVLO = QtWidgets.QVBoxLayout()
        brCnKsVLO.setSpacing(10)

        checkBoxButVLO = QtWidgets.QVBoxLayout()
        checkBoxButVLO.setSpacing(10)

        '''HLOs'''
        noizeHLO = QtWidgets.QHBoxLayout()
        flareHLO = QtWidgets.QHBoxLayout()
        perspective_hlo = QtWidgets.QHBoxLayout()
        checkBoxButHLO = QtWidgets.QHBoxLayout()

        l_dist_hlo = QtWidgets.QHBoxLayout()
        r_dist_hlo = QtWidgets.QHBoxLayout()
        b_dist_hlo = QtWidgets.QHBoxLayout()
        angle_grid_hlo = QtWidgets.QHBoxLayout()

        min_angle_hlo = QtWidgets.QHBoxLayout()
        max_angle_hlo = QtWidgets.QHBoxLayout()
        angle_step_hlo = QtWidgets.QHBoxLayout()

        min_size_hlo = QtWidgets.QHBoxLayout()
        max_size_hlo = QtWidgets.QHBoxLayout()
        size_step_hlo = QtWidgets.QHBoxLayout()

        brightnessHLO = QtWidgets.QHBoxLayout()
        contrastHLO = QtWidgets.QHBoxLayout()
        kSizeHLO = QtWidgets.QHBoxLayout()

        angle_sizeGridLO = QtWidgets.QGridLayout()
        ChBoxesGridLO = QtWidgets.QGridLayout()

        self.angleGB = QtWidgets.QGroupBox()
        self.sizeGB = QtWidgets.QGroupBox()
        self.brightness_contrast_kernelSize = QtWidgets.QGroupBox()
        self.ChBoxesButtonsGB  = QtWidgets.QGroupBox()

        '''HLOs assignment'''
        noizeHLO.addWidget(self.noized_chb)
        noizeHLO.addWidget(self.noized)
        noizeHLO.addStretch()

        flareHLO.addWidget(self.flared_chb)
        flareHLO.addWidget(self.flared)
        flareHLO.addStretch()

        perspective_hlo.addWidget(self.distortion_direction)
        l_dist_hlo.addWidget(self.l_dist_chb)
        l_dist_hlo.addWidget(self.l_dist)
        l_dist_hlo.addWidget(self.l_dist_slider)
        l_dist_hlo.addWidget(self.l_dist_spin)
        r_dist_hlo.addWidget(self.r_dist_chb)
        r_dist_hlo.addWidget(self.r_dist)
        r_dist_hlo.addWidget(self.r_dist_slider)
        r_dist_hlo.addWidget(self.r_dist_spin)
        b_dist_hlo.addWidget(self.b_dist_chb)
        b_dist_hlo.addWidget(self.b_dist)
        b_dist_hlo.addWidget(self.b_dist_slider)
        b_dist_hlo.addWidget(self.b_dist_spin)

        min_angle_hlo.addWidget(self.min_angle_chb)
        min_angle_hlo.addWidget(self.min_angle)
        min_angle_hlo.addWidget(self.min_angle_spin)
        min_angle_hlo.addStretch()
        max_angle_hlo.addWidget(self.max_angle_chb)
        max_angle_hlo.addWidget(self.max_angle)
        max_angle_hlo.addWidget(self.max_angle_spin)
        max_angle_hlo.addStretch()
        angle_step_hlo.addStretch()
        angle_step_hlo.addWidget(self.step_angle)
        angle_step_hlo.addStretch()
        angle_step_hlo.addWidget(self.step_angle_spin)
        angle_step_hlo.addStretch()

        min_size_hlo.addWidget(self.min_size_chb)
        min_size_hlo.addWidget(self.min_size)
        min_size_hlo.addWidget(self.min_size_spin)
        min_size_hlo.addStretch()
        max_size_hlo.addWidget(self.max_size_chb)
        max_size_hlo.addWidget(self.max_size)
        max_size_hlo.addWidget(self.max_size_spin)
        max_size_hlo.addStretch()

        size_step_hlo.addStretch()
        size_step_hlo.addWidget(self.step_size)
        size_step_hlo.addStretch()
        size_step_hlo.addWidget(self.step_size_spin)
        size_step_hlo.addStretch()

        brightnessHLO.addWidget(self.brightness_chb)
        brightnessHLO.addWidget(self.brightness)
        brightnessHLO.addWidget(self.brightness_slider)
        brightnessHLO.addWidget(self.brightness_spin)

        contrastHLO.addWidget(self.contrast_chb)
        contrastHLO.addWidget(self.contrast)
        contrastHLO.addWidget(self.contrast_slider)
        contrastHLO.addWidget(self.contrast_spin)

        kSizeHLO.addWidget(self.kernel_chb)
        kSizeHLO.addWidget(self.kernel)
        kSizeHLO.addWidget(self.k_size_slider)
        kSizeHLO.addWidget(self.kernel_size_spin)

        angle_grid_hlo.addLayout(angle_sizeGridLO)
        angle_sizeGridLO.addWidget(self.angleGB,1,0)

        angle_sizeGridLO.addWidget(self.sizeGB, 1, 1)

        checkBoxButHLO.addLayout(ChBoxesGridLO)
        ChBoxesGridLO.addWidget(self.ChBoxesButtonsGB,0,0)

        '''vertical layouts'''
        distortionVLayOut.addLayout(perspective_hlo)
        distortionVLayOut.addLayout(l_dist_hlo)
        distortionVLayOut.addLayout(r_dist_hlo)
        distortionVLayOut.addLayout(b_dist_hlo)

        angleVLayOut.addWidget(self.rotate_angl)
        angleVLayOut.addLayout(min_angle_hlo)
        angleVLayOut.addLayout(max_angle_hlo)
        angleVLayOut.addLayout(angle_step_hlo)

        sizeVLayOut.addWidget(self.img_size)
        sizeVLayOut.addLayout(min_size_hlo)
        sizeVLayOut.addLayout(max_size_hlo)
        sizeVLayOut.addLayout(size_step_hlo)

        brCnKsVLO.addWidget(self.texture_transformations)
        brCnKsVLO.addLayout(brightnessHLO)
        brCnKsVLO.addLayout(contrastHLO)
        brCnKsVLO.addLayout(kSizeHLO)

        checkBoxButVLO.addWidget(self.other_effects)
        checkBoxButVLO.addLayout(noizeHLO)
        checkBoxButVLO.addLayout(flareHLO)

        self.angleGB.setLayout(angleVLayOut)
        self.sizeGB.setLayout(sizeVLayOut)
        self.brightness_contrast_kernelSize.setLayout(brCnKsVLO)
        self.ChBoxesButtonsGB.setLayout(checkBoxButVLO)

        '''main vertical layout'''
        vertLayOut.addWidget(self.settings_label)
        vertLayOut.addLayout(kernelVLayOut)
        self.gb1.setLayout(distortionVLayOut)
        vertLayOut.addWidget(self.gb1)
        vertLayOut.addSpacing(0)

        vertLayOut.addLayout(angle_grid_hlo)

        vertLayOut.addWidget(self.brightness_contrast_kernelSize)

        vertLayOut.addLayout(checkBoxButHLO)
        vertLayOut.addStretch()
        vertLayOut.addWidget(self.preview_button)
        vertLayOut.addWidget(self.generate_button)
        vertLayOut.addWidget(self.total_pictures_to_generate)
        self.groupBox.setLayout(vertLayOut)

        self.zoomWidget = ZoomWidget()
        self.colorDialog = ColorDialog(parent=self)

        self.canvas = self.labelList.canvas = Canvas(
            epsilon=self._config['epsilon'],
        )
        self.canvas.zoomRequest.connect(self.zoomRequest)

        self.canvas_grid = self.labelList.canvas = Canvas(
            epsilon=self._config['epsilon'],
        )

        self.canvas.thread()

        scrollArea = QtWidgets.QScrollArea()
        scrollArea.setWidget(self.canvas)
        scrollArea.setWidgetResizable(True)

        self.scrollBars = {
            Qt.Vertical: scrollArea.verticalScrollBar(),
            Qt.Horizontal: scrollArea.horizontalScrollBar(),
        }
        self.canvas.scrollRequest.connect(self.scrollRequest)

        self.canvas.newShape.connect(self.newShape)
        self.canvas.shapeMoved.connect(self.setDirty)
        self.canvas.selectionChanged.connect(self.shapeSelectionChanged)
        self.canvas.drawingPolygon.connect(self.toggleDrawingSensitive)
        self.setCentralWidget(scrollArea)

        fileListWidgetP = QtWidgets.QWidget()
        fileListWidgetP.setLayout(fileListLayoutP)
        self.file_dockP.setWidget(fileListWidgetP)

        features = QtWidgets.QDockWidget.DockWidgetFeatures()
        for dock in ['flag_dock', 'label_dock', 'shape_dock', 'file_dock', 'file_dockP']:
            if self._config[dock]['closable']:
                features = features | QtWidgets.QDockWidget.DockWidgetClosable
            if self._config[dock]['floatable']:
                features = features | QtWidgets.QDockWidget.DockWidgetFloatable
            if self._config[dock]['movable']:
                features = features | QtWidgets.QDockWidget.DockWidgetMovable
            getattr(self, dock).setFeatures(features)
            if self._config[dock]['show'] is False:
                getattr(self, dock).setVisible(False)

        self.addDockWidget(Qt.TopDockWidgetArea, self.flag_dock)
        self.addDockWidget(Qt.RightDockWidgetArea, self.label_dock)
        self.addDockWidget(Qt.RightDockWidgetArea, self.shape_dock)
        self.addDockWidget(Qt.RightDockWidgetArea, self.file_dock)
        self.addDockWidget(Qt.RightDockWidgetArea, self.file_dockP)

        self.file_dock.setFeatures(QtWidgets.QDockWidget.NoDockWidgetFeatures)
        self.file_dockP.setFeatures(QtWidgets.QDockWidget.NoDockWidgetFeatures)

        self.file_dock.visibilityChanged.connect(self.calculate_pict_among)

        self.tabifyDockWidget(self.file_dock,self.file_dockP)
        self.file_dock.show()
        self.file_dock.raise_()

        '''ACTIONS'''
        action = functools.partial(newAction, self)
        shortcuts = self._config['shortcuts']
        quit = action('&Quit', self.close, shortcuts['quit'], 'quit',
                      'Quit application')
        open_ = action('&Open', self.openFile, shortcuts['open'], 'open',
                       'Open image or label file')
        opendir = action('&Open Dir', self.openDirDialog,
                         shortcuts['open_dir'], 'open', u'Open Dir')
        openNextImg = action(
            '&Next Image',
            self.openNextImg,
            shortcuts['open_next'],
            'next',
            u'Open next (hold Ctl+Shift to copy labels)',
            enabled=False,
        )
        openPrevImg = action(
            '&Prev Image',
            self.openPrevImg,
            shortcuts['open_prev'],
            'prev',
            u'Open prev (hold Ctl+Shift to copy labels)',
            enabled=False,
        )
        save = action('&Save', self.saveFile, shortcuts['save'], 'save',
                      'Save labels to file', enabled=False)
        saveAs = action('&Save As', self.saveFileAs, shortcuts['save_as'],
                        'save-as', 'Save labels to a different file',
                        enabled=False)

        changeOutputDir = action(
            '&Change Output Dir',
            slot=self.changeOutputDirDialog,
            shortcut=shortcuts['save_to'],
            icon='open',
            tip=u'Change where annotations are loaded/saved'
        )

        saveAuto = action(
            text='Save &Automatically',
            slot=lambda x: self.actions.saveAuto.setChecked(x),
            icon='save',
            tip='Save automatically',
            checkable=True,
            enabled=True,
        )
        saveAuto.setChecked(self._config['auto_save'])

        close = action('&Close', self.closeFile, shortcuts['close'], 'close',
                       'Close current file')
        color1 = action('Polygon &Line Color', self.chooseColor1,
                        shortcuts['edit_line_color'], 'color_line',
                        'Choose polygon line color')
        color2 = action('Polygon &Fill Color', self.chooseColor2,
                        shortcuts['edit_fill_color'], 'color',
                        'Choose polygon fill color')

        toggle_keep_prev_mode = action(
            'Keep Previous Annotation',
            self.toggleKeepPrevMode,
            shortcuts['toggle_keep_prev_mode'], None,
            'Toggle "keep pevious annotation" mode',
            checkable=True)
        toggle_keep_prev_mode.setChecked(self._config['keep_prev'])

        createMode = action(
            'Create Polygons',
            lambda: self.toggleDrawMode(False, createMode='polygon'),
            shortcuts['create_polygon'],
            'objects',
            'Start drawing polygons',
            enabled=False,
        )
        createRectangleMode = action(
            'Create Rectangle',
            lambda: self.toggleDrawMode(False, createMode='rectangle'),
            shortcuts['create_rectangle'],
            'objects',
            'Start drawing rectangles',
            enabled=False,
        )
        createCircleMode = action(
            'Create Circle',
            lambda: self.toggleDrawMode(False, createMode='circle'),
            shortcuts['create_circle'],
            'objects',
            'Start drawing circles',
            enabled=False,
        )
        createLineMode = action(
            'Create Line',
            lambda: self.toggleDrawMode(False, createMode='line'),
            shortcuts['create_line'],
            'objects',
            'Start drawing lines',
            enabled=False,
        )
        createPointMode = action(
            'Create Point',
            lambda: self.toggleDrawMode(False, createMode='point'),
            shortcuts['create_point'],
            'objects',
            'Start drawing points',
            enabled=False,
        )
        createLineStripMode = action(
            'Create LineStrip',
            lambda: self.toggleDrawMode(False, createMode='linestrip'),
            shortcuts['create_linestrip'],
            'objects',
            'Start drawing linestrip. Ctrl+LeftClick ends creation.',
            enabled=False,
        )
        editMode = action('Edit Polygons', self.setEditMode,
                          shortcuts['edit_polygon'], 'edit',
                          'Move and edit polygons', enabled=False)

        delete = action('Delete Polygon', self.deleteSelectedShape,
                        shortcuts['delete_polygon'], 'cancel',
                        'Delete', enabled=False)
        copy = action('Duplicate Polygon', self.copySelectedShape,
                      shortcuts['duplicate_polygon'], 'copy',
                      'Create a duplicate of the selected polygon',
                      enabled=False)
        undoLastPoint = action('Undo last point', self.canvas.undoLastPoint,
                               shortcuts['undo_last_point'], 'undo',
                               'Undo last drawn point', enabled=False)
        addPoint = action('Add Point to Edge', self.canvas.addPointToEdge,
                          None, 'edit', 'Add point to the nearest edge',
                          enabled=False)

        undo = action('Undo', self.undoShapeEdit, shortcuts['undo'], 'undo',
                      'Undo last add and edit of shape', enabled=False)

        hideAll = action('&Hide\nPolygons',
                         functools.partial(self.togglePolygons, False),
                         icon='eye', tip='Hide all polygons', enabled=False)
        showAll = action('&Show\nPolygons',
                         functools.partial(self.togglePolygons, True),
                         icon='eye', tip='Show all polygons', enabled=False)

        help = action('&Tutorial', self.tutorial, icon='help',
                      tip='Show tutorial page')

        zoom = QtWidgets.QWidgetAction(self)
        zoom.setDefaultWidget(self.zoomWidget)
        self.zoomWidget.setWhatsThis(
            "Zoom in or out of the image. Also accessible with"
            " %s and %s from the canvas." %
            (fmtShortcut('%s,%s' % (shortcuts['zoom_in'],
                                    shortcuts['zoom_out'])),
             fmtShortcut("Ctrl+Wheel")))
        self.zoomWidget.setEnabled(False)

        zoomIn = action('Zoom &In', functools.partial(self.addZoom, 10),
                        shortcuts['zoom_in'], 'zoom-in',
                        'Increase zoom level', enabled=False)
        zoomOut = action('&Zoom Out', functools.partial(self.addZoom, -10),
                         shortcuts['zoom_out'], 'zoom-out',
                         'Decrease zoom level', enabled=False)
        zoomOrg = action('&Original size',
                         functools.partial(self.setZoom, 100),
                         shortcuts['zoom_to_original'], 'zoom',
                         'Zoom to original size', enabled=False)
        fitWindow = action('&Fit Window', self.setFitWindow,
                           shortcuts['fit_window'], 'fit-window',
                           'Zoom follows window size', checkable=True,
                           enabled=False)
        fitWidth = action('Fit &Width', self.setFitWidth,
                          shortcuts['fit_width'], 'fit-width',
                          'Zoom follows window width',
                          checkable=True, enabled=False)
        remove_sample = action('&Remove selected', self.remove_sample,
                          shortcuts['rem_sampl'], 'cancel',
                          'Remove selected sample', enabled = False)
        generation_settings = action('&Settings', self.generation_settings,
                               shortcuts['rem_sampl'], 'settings',
                               'Settings for picture generation',
                                checkable=True,enabled=False)

        create_samples = action('Create Samples', self.create_samples_button,
                               shortcuts['rem_sampl'], 'generate',
                               'Generate samples for training',
                                enabled=False)

        save_format = action('VOC/YOLO', self.change_format,
                      shortcuts['toggle_yolo_xml'], 'format_voc', "Set format for annotation file", enabled=True)

        change_annotation = action('&Change annotation', self.openAnnotationDialog,
                      shortcuts['change_annotation'], 'change_annotation', "Change fields XML annotation file", enabled=True)

        # Group zoom controls into a list for easier toggling.
        zoomActions = (self.zoomWidget, zoomIn, zoomOut, zoomOrg,
                       fitWindow, fitWidth)
        self.zoomMode = self.MANUAL_ZOOM
        # fitWindow.setChecked(Qt.Checked)
        self.scalers = {
            self.FIT_WINDOW: self.scaleFitWindow,
            self.FIT_WIDTH: self.scaleFitWidth,
            # Set to one to scale to 100% when loading files.
            self.MANUAL_ZOOM: lambda: 1,
        }

        edit = action('&Edit Label', self.editLabel, shortcuts['edit_label'],
                      'edit', 'Modify the label of the selected polygon',
                      enabled=False)

        shapeLineColor = action(
            'Shape &Line Color', self.chshapeLineColor, icon='color-line',
            tip='Change the line color for this specific shape', enabled=False)
        shapeFillColor = action(
            'Shape &Fill Color', self.chshapeFillColor, icon='color',
            tip='Change the fill color for this specific shape', enabled=False)
        fill_drawing = action(
            'Fill Drawing Polygon',
            lambda x: self.canvas.setFillDrawing(x),
            None,
            'color',
            'Fill polygon while drawing',
            checkable=True,
            enabled=True,
        )
        fill_drawing.setChecked(True)

        # Lavel list context menu.
        labelMenu = QtWidgets.QMenu()
        addActions(labelMenu, (edit, delete))
        self.labelList.setContextMenuPolicy(Qt.CustomContextMenu)
        self.labelList.customContextMenuRequested.connect(
            self.popLabelListMenu)

        # Store actions for further handling.
        self.actions = struct(
            saveAuto=saveAuto,
            changeOutputDir=changeOutputDir,
            save=save, saveAs=saveAs, save_format=save_format,
            open=open_, close=close,
            lineColor=color1, fillColor=color2,
            toggleKeepPrevMode=toggle_keep_prev_mode,
            delete=delete, edit=edit, copy=copy,
            undoLastPoint=undoLastPoint, undo=undo,
            addPoint=addPoint,
            createMode=createMode, editMode=editMode,
            createRectangleMode=createRectangleMode,
            createCircleMode=createCircleMode,
            createLineMode=createLineMode,
            createPointMode=createPointMode,
            createLineStripMode=createLineStripMode,
            shapeLineColor=shapeLineColor, shapeFillColor=shapeFillColor,
            zoom=zoom, zoomIn=zoomIn, zoomOut=zoomOut, zoomOrg=zoomOrg,
            fitWindow=fitWindow, fitWidth=fitWidth,
            remove_sample=remove_sample,generation_settings=generation_settings,
            create_samples=create_samples,change_annotation=change_annotation,
            zoomActions=zoomActions,
            openNextImg=openNextImg, openPrevImg=openPrevImg,
            fileMenuActions=(open_, opendir, save, saveAs, close, quit),
            tool=(),
            editMenu=(edit, copy, delete, None, undo, undoLastPoint,
                      None, color1, color2, None, toggle_keep_prev_mode),
            # menu shown at right click
            menu=(
                createMode,
                createRectangleMode,
                createCircleMode,
                createLineMode,
                createPointMode,
                createLineStripMode,
                editMode,
                edit,
                copy,
                delete,
                shapeLineColor,
                shapeFillColor,
                undo,
                undoLastPoint,
                addPoint,
            ),
            onLoadActive=(
                close,
                createMode,
                createRectangleMode,
                createCircleMode,
                createLineMode,
                createPointMode,
                createLineStripMode,
                editMode,
            ),
            onShapesPresent=(saveAs, hideAll, showAll),
        )

        self.canvas.edgeSelected.connect(self.actions.addPoint.setEnabled)

        self.menus = struct(
            file=self.menu('&File'),
            edit=self.menu('&Edit'),
            view=self.menu('&View'),
            help=self.menu('&Help'),
            recentFiles=QtWidgets.QMenu('Open &Recent'),
            labelList=labelMenu,
        )

        addActions(self.menus.file, (open_, openNextImg, openPrevImg, opendir,
                                     self.menus.recentFiles,
                                     save, save_format, saveAs, saveAuto, changeOutputDir,
                                     close,
                                     None,
                                     quit))
        addActions(self.menus.help, (help,))

        addActions(self.menus.view, (
            self.flag_dock.toggleViewAction(),
            self.label_dock.toggleViewAction(),
            self.shape_dock.toggleViewAction(),
            None,
            fill_drawing,
            None,
            hideAll,
            showAll,
            None,
            zoomIn,
            zoomOut,
            zoomOrg,
            None,
            fitWindow,
            fitWidth,
            None,
        ))

        self.menus.file.aboutToShow.connect(self.updateFileMenu)

        # Custom context menu for the canvas widget:
        addActions(self.canvas.menus[0], self.actions.menu)
        addActions(self.canvas.menus[1], (
            action('&Copy here', self.copyShape),
            action('&Move here', self.moveShape)))

        self.tools = self.toolbar('Tools')

        # Menu buttons on Left
        self.actions.tool = (
            open_,
            opendir,
            changeOutputDir,
            openNextImg,
            openPrevImg,
            save,
            None,
            createMode,
            editMode,
            copy,
            delete,
            undo,
            None,
            zoomIn,
            zoom,
            zoomOut,
            fitWindow,
            fitWidth,
            None,
            remove_sample,
            generation_settings,
            create_samples,
            save_format,
            change_annotation
        )

        self.statusBar().showMessage('%s started.' % __appname__)
        self.statusBar().show()

        if output_file is not None and self._config['auto_save']:
            logger.warn(
                'If `auto_save` argument is True, `output_file` argument '
                'is ignored and output filename is automatically '
                'set as IMAGE_BASENAME.json.'
            )
        self.output_file = output_file
        self.output_dir = output_dir

        # Application state.
        self.image = QtGui.QImage()
        self.imagePath = None
        self.recentFiles = []
        self.maxRecent = 7
        self.lineColor = None
        self.fillColor = None
        self.otherData = None
        self.zoom_level = 100
        self.fit_window = False

        if filename is not None and osp.isdir(filename):
            self.importDirImages(filename, load=False)
        else:
            self.filename = filename

        if config['file_search']:
            self.fileSearch.setText(config['file_search'])
            self.fileSearchChanged()

        # XXX: Could be completely declarative.
        # Restore application settings.
        self.settings = QtCore.QSettings('labelme', 'labelme')
        # FIXME: QSettings.value can return None on PyQt4
        self.recentFiles = self.settings.value('recentFiles', []) or []
        size = self.settings.value('window/size', QtCore.QSize(600, 500))
        position = self.settings.value('window/position', QtCore.QPoint(0, 0))
        self.resize(size)
        self.move(position)
        # or simply:
        # self.restoreGeometry(settings['window/geometry']
        self.restoreState(
            self.settings.value('window/state', QtCore.QByteArray()))
        self.lineColor = QtGui.QColor(
            self.settings.value('line/color', Shape.line_color))
        self.fillColor = QtGui.QColor(
            self.settings.value('fill/color', Shape.fill_color))
        Shape.line_color = self.lineColor
        Shape.fill_color = self.fillColor

        # Populate the File menu dynamically.
        self.updateFileMenu()
        # Since loading the file may take some time,
        # make sure it runs in the background.
        if self.filename is not None:
            self.queueEvent(functools.partial(self.loadFile, self.filename))

        # Callbacks:
        self.zoomWidget.valueChanged.connect(self.paintCanvas)

        self.populateModeActions()

        # self.firstStart = True
        # if self.firstStart:
        #    QWhatsThis.enterWhatsThisMode()

        self.l_dist_spin.setValue(int(self.settings.value("leftP")))
        self.r_dist_spin.setValue(int(self.settings.value("rightP")))
        self.b_dist_spin.setValue(int(self.settings.value("botP")))

        self.min_angle_spin.setValue(int(self.settings.value("minAngle")))
        self.max_angle_spin.setValue(int(self.settings.value("maxAngle")))

        self.min_size_spin.setValue(int(self.settings.value("minSize")))
        self.max_size_spin.setValue(int(self.settings.value("maxSize")))

        self.brightness_spin.setValue(int(self.settings.value("brightness")))
        self.contrast_spin.setValue(int(self.settings.value("contrast")))
        self.kernel_size_spin.setValue(int(self.settings.value("kernelSize")))

        if self.settings.value("noized") == 'true':
            self.noized_chb.setChecked(True)
            self.noized.setEnabled(True)
        if self.settings.value("flared") == 'true':
            self.flared_chb.setChecked(True)
            self.flared.setEnabled(True)

    # Support Functions

    def calculate_pict_among(self):
        items = self.fileListWidget.count()

        angle_min = 1
        angle_max = 1
        perspective = 1

        if self.min_angle_chb.isChecked() and self.max_angle_chb.isChecked():
            self.step_angle_spin.setRange(1,self.min_angle_spin.value() + self.max_angle_spin.value())
            angle_range = range(self.min_angle_spin.value().__neg__(), self.max_angle_spin.value() + 1, self.step_angle_spin.value())
            total_angle = len(angle_range)
            if not angle_range.__contains__(0):
                total_angle += 1
        else:
            total_angle = 1
        if self.min_angle_chb.isChecked() and not self.max_angle_chb.isChecked():
            self.step_angle_spin.setRange(1,self.min_angle_spin.value())
            angle_min = len(range(self.min_angle_spin.value().__neg__(),0,self.step_angle_spin.value())) + 1
            angle_max = 1
        if not self.min_angle_chb.isChecked() and self.max_angle_chb.isChecked():
            self.step_angle_spin.setRange(1,self.max_angle_spin.value())
            if self.step_angle_spin.value() == 1:
                angle_max = len(range(0,self.max_angle_spin.value(),self.step_angle_spin.value())) + 1
            else:
                angle_max = len(range(0,self.max_angle_spin.value() + 1,self.step_angle_spin.value()))
            angle_min = 1

        self.step_size_spin.setRange(1,self.max_size_spin.value() - self.min_size_spin.value())

        noized = 2 if self.noized_chb.isChecked() else 1
        flared = 2 if self.flared_chb.isChecked() else 1
        contrast = 2 if self.contrast_chb.isChecked() else 1
        brightness = 2 if self.brightness_chb.isChecked() else 1
        blured = len(range(1, self.kernel_size_spin.value() + 1, 2)) if self.kernel_chb.isChecked() else 1

        l_dist = 2 if self.l_dist_chb.isChecked() else 1
        r_dist = 2 if self.r_dist_chb.isChecked() else 1
        b_dist = 2 if self.b_dist_chb.isChecked() else 1

        if l_dist*r_dist*b_dist == 8:
            perspective = 4
        elif l_dist*r_dist*b_dist == 4:
            perspective = 3
        elif l_dist*r_dist*b_dist == 2:
            perspective = 2

        if self.min_size_chb.isChecked() or self.max_size_chb.isChecked():
            resized = len(range(self.min_size_spin.value(), self.max_size_spin.value() + 1, self.step_size_spin.value()))
        else: resized = 1


        self.pictures_total = items * noized * flared * blured * \
                              total_angle * angle_max * angle_min * \
                              perspective * resized * contrast * brightness

        self.total_pictures_to_generate.setText("Total pictures to generate: {}".format(self.pictures_total))

    def min_size_editing_finished(self):
        if self.min_size_spin.value() % self.step_size_spin.value():
            self.min_size_spin.setValue(
                math.ceil(self.step_size_spin.value() * (self.min_size_spin.value() / self.step_size_spin.value())))
    def max_size_editing_finished(self):
        if  self.max_size_spin.value() % self.step_size_spin.value():
            self.max_size_spin.setValue(
                math.ceil(self.step_size_spin.value() * (self.max_size_spin.value() / self.step_size_spin.value())))

    def step_size_editining_finished(self):
        self.min_size_spin.setSingleStep(self.step_size_spin.value())
        self.max_size_spin.setSingleStep(self.step_size_spin.value())

    def step_angle_editining_finished(self):
        self.min_angle_spin.setSingleStep(self.step_angle_spin.value())
        self.max_angle_spin.setSingleStep(self.step_angle_spin.value())


    def left_perspective(self):
        self.calculate_pict_among()
        self.l_dist.setEnabled(not self.l_dist.isEnabled())
        self.l_dist_slider.setEnabled(not self.l_dist_slider.isEnabled())
        self.l_dist_spin.setEnabled(not self.l_dist_spin.isEnabled())
        if self.l_dist_chb.isChecked():
            self.directions.append("l")
        else: self.directions.remove("l")

    def right_perspective(self):
        self.calculate_pict_among()
        self.r_dist.setEnabled(not self.r_dist.isEnabled())
        self.r_dist_slider.setEnabled(not self.r_dist_slider.isEnabled())
        self.r_dist_spin.setEnabled(not self.r_dist_spin.isEnabled())
        if self.r_dist_chb.isChecked():
            self.directions.append("r")
        else: self.directions.remove("r")

    def bottom_perspective(self):
        self.calculate_pict_among()
        self.b_dist.setEnabled(not self.b_dist.isEnabled())
        self.b_dist_slider.setEnabled(not self.b_dist_slider.isEnabled())
        self.b_dist_spin.setEnabled(not self.b_dist_spin.isEnabled())
        if self.b_dist_chb.isChecked():
            self.directions.append("b")
        else: self.directions.remove("b")

    def kernel_chb_toggled(self):
        self.calculate_pict_among()
        self.kernel.setEnabled(not self.kernel.isEnabled())
        self.k_size_slider.setEnabled(not self.k_size_slider.isEnabled())
        self.kernel_size_spin.setEnabled(not self.kernel_size_spin.isEnabled())

    def contrast_chb_toggled(self):
        self.calculate_pict_among()
        self.contrast.setEnabled(not self.contrast.isEnabled())
        self.contrast_slider.setEnabled(not self.contrast_slider.isEnabled())
        self.contrast_spin.setEnabled(not self.contrast_spin.isEnabled())

    def brightness_chb_toggled(self):
        self.calculate_pict_among()
        self.brightness.setEnabled(not self.brightness.isEnabled())
        self.brightness_slider.setEnabled(not self.brightness_slider.isEnabled())
        self.brightness_spin.setEnabled(not self.brightness_spin.isEnabled())

    def min_angle_chb_toggled(self):
        self.calculate_pict_among()
        self.min_angle.setEnabled(not self.min_angle.isEnabled())
        self.min_angle_spin.setEnabled(not self.min_angle_spin.isEnabled())

        if not self.max_angle_chb.isChecked():
            self.step_angle.setEnabled(not self.step_angle.isEnabled())
            self.step_angle_spin.setEnabled(not self.step_angle_spin.isEnabled())

    def max_angle_chb_toggled(self):
        self.calculate_pict_among()
        self.max_angle.setEnabled(not self.max_angle.isEnabled())
        self.max_angle_spin.setEnabled(not self.max_angle_spin.isEnabled())

        if not self.min_angle_chb.isChecked():
            self.step_angle.setEnabled(not self.step_angle.isEnabled())
            self.step_angle_spin.setEnabled(not self.step_angle_spin.isEnabled())

    def min_size_chb_toggled(self):
        self.calculate_pict_among()
        self.min_size.setEnabled(not self.min_size.isEnabled())
        self.min_size_spin.setEnabled(not self.min_size_spin.isEnabled())

        if not self.max_size_chb.isChecked():
            self.step_size.setEnabled(not self.step_size.isEnabled())
            self.step_size_spin.setEnabled(not self.step_size_spin.isEnabled())

    def max_size_chb_toggled(self):
        self.calculate_pict_among()
        self.max_size.setEnabled(not self.max_size.isEnabled())
        self.max_size_spin.setEnabled(not self.max_size_spin.isEnabled())

        if not self.min_size_chb.isChecked():
            self.step_size.setEnabled(not self.step_size.isEnabled())
            self.step_size_spin.setEnabled(not self.step_size_spin.isEnabled())

    def noShapes(self):
        return not self.labelList.itemsToShapes

    def populateModeActions(self):
        tool, menu = self.actions.tool, self.actions.menu
        self.tools.clear()
        addActions(self.tools, tool)
        self.canvas.menus[0].clear()
        addActions(self.canvas.menus[0], menu)
        self.menus.edit.clear()
        actions = (
            self.actions.createMode,
            self.actions.createRectangleMode,
            self.actions.createCircleMode,
            self.actions.createLineMode,
            self.actions.createPointMode,
            self.actions.createLineStripMode,
            self.actions.editMode,
        )
        addActions(self.menus.edit, actions + self.actions.editMenu)

    def setDirty(self):
        if self._config['auto_save'] or self.actions.saveAuto.isChecked():
            label_file = osp.splitext(self.imagePath)[0] + '.json'
            if self.output_dir:
                label_file = osp.join(self.output_dir, label_file)
            self.saveLabels(label_file)
            return
        self.dirty = True
        self.actions.save.setEnabled(True)
        self.actions.undo.setEnabled(self.canvas.isShapeRestorable)
        title = __appname__
        if self.filename is not None:
            title = '{} - {}*'.format(title, self.filename)
        self.setWindowTitle(title)

    def setClean(self):
        self.dirty = False
        self.actions.save.setEnabled(False)
        self.actions.createMode.setEnabled(True)
        self.actions.createRectangleMode.setEnabled(True)
        self.actions.createCircleMode.setEnabled(True)
        self.actions.createLineMode.setEnabled(True)
        self.actions.createPointMode.setEnabled(True)
        self.actions.createLineStripMode.setEnabled(True)
        title = __appname__
        if self.filename is not None:
            title = '{} - {}'.format(title, self.filename)
        self.setWindowTitle(title)

    def toggleActions(self, value=True):
        """Enable/Disable widgets which depend on an opened image."""
        for z in self.actions.zoomActions:
            z.setEnabled(value)
        for action in self.actions.onLoadActive:
            action.setEnabled(value)

    def queueEvent(self, function):
        QtCore.QTimer.singleShot(0, function)

    def status(self, message, delay=5000):
        self.statusBar().showMessage(message, delay)

    def resetState(self):
        self.labelList.clear()
        self.filename = None
        self.imagePath = None
        self.imageData = None
        self.labelFile = None
        self.otherData = None
        self.canvas.resetState()

    def currentItem(self):
        items = self.labelList.selectedItems()
        if items:
            return items[0]
        return None

    def addRecentFile(self, filename):
        if filename in self.recentFiles:
            self.recentFiles.remove(filename)
        elif len(self.recentFiles) >= self.maxRecent:
            self.recentFiles.pop()
        self.recentFiles.insert(0, filename)

    # Callbacks

    def undoShapeEdit(self):
        self.canvas.restoreShape()
        self.labelList.clear()
        self.loadShapes(self.canvas.shapes)
        self.actions.undo.setEnabled(self.canvas.isShapeRestorable)

    def tutorial(self):
        url = 'https://github.com/wkentaro/labelme/tree/master/examples/tutorial'  # NOQA
        webbrowser.open(url)

    def toggleAddPointEnabled(self, enabled):
        self.actions.addPoint.setEnabled(enabled)

    def toggleDrawingSensitive(self, drawing=True):
        """Toggle drawing sensitive.

        In the middle of drawing, toggling between modes should be disabled.
        """
        self.actions.editMode.setEnabled(not drawing)
        self.actions.undoLastPoint.setEnabled(drawing)
        self.actions.undo.setEnabled(not drawing)
        self.actions.delete.setEnabled(not drawing)

    def toggleDrawMode(self, edit=True, createMode='polygon'):
        self.canvas.setEditing(edit)
        self.canvas.createMode = createMode
        if edit:
            self.actions.createMode.setEnabled(True)
            self.actions.createRectangleMode.setEnabled(True)
            self.actions.createCircleMode.setEnabled(True)
            self.actions.createLineMode.setEnabled(True)
            self.actions.createPointMode.setEnabled(True)
            self.actions.createLineStripMode.setEnabled(True)
        else:
            if createMode == 'polygon':
                self.actions.createMode.setEnabled(False)
                self.actions.createRectangleMode.setEnabled(True)
                self.actions.createCircleMode.setEnabled(True)
                self.actions.createLineMode.setEnabled(True)
                self.actions.createPointMode.setEnabled(True)
                self.actions.createLineStripMode.setEnabled(True)
            elif createMode == 'rectangle':
                self.actions.createMode.setEnabled(True)
                self.actions.createRectangleMode.setEnabled(False)
                self.actions.createCircleMode.setEnabled(True)
                self.actions.createLineMode.setEnabled(True)
                self.actions.createPointMode.setEnabled(True)
                self.actions.createLineStripMode.setEnabled(True)
            elif createMode == 'line':
                self.actions.createMode.setEnabled(True)
                self.actions.createRectangleMode.setEnabled(True)
                self.actions.createCircleMode.setEnabled(True)
                self.actions.createLineMode.setEnabled(False)
                self.actions.createPointMode.setEnabled(True)
                self.actions.createLineStripMode.setEnabled(True)
            elif createMode == 'point':
                self.actions.createMode.setEnabled(True)
                self.actions.createRectangleMode.setEnabled(True)
                self.actions.createCircleMode.setEnabled(True)
                self.actions.createLineMode.setEnabled(True)
                self.actions.createPointMode.setEnabled(False)
                self.actions.createLineStripMode.setEnabled(True)
            elif createMode == "circle":
                self.actions.createMode.setEnabled(True)
                self.actions.createRectangleMode.setEnabled(True)
                self.actions.createCircleMode.setEnabled(False)
                self.actions.createLineMode.setEnabled(True)
                self.actions.createPointMode.setEnabled(True)
                self.actions.createLineStripMode.setEnabled(True)
            elif createMode == "linestrip":
                self.actions.createMode.setEnabled(True)
                self.actions.createRectangleMode.setEnabled(True)
                self.actions.createCircleMode.setEnabled(True)
                self.actions.createLineMode.setEnabled(True)
                self.actions.createPointMode.setEnabled(True)
                self.actions.createLineStripMode.setEnabled(False)
            else:
                raise ValueError('Unsupported createMode: %s' % createMode)
        self.actions.editMode.setEnabled(not edit)

    def setEditMode(self):
        self.toggleDrawMode(True)

    def updateFileMenu(self):
        current = self.filename

        def exists(filename):
            return osp.exists(str(filename))

        menu = self.menus.recentFiles
        menu.clear()
        files = [f for f in self.recentFiles if f != current and exists(f)]
        for i, f in enumerate(files):
            icon = newIcon('labels')
            action = QtWidgets.QAction(
                icon, '&%d %s' % (i + 1, QtCore.QFileInfo(f).fileName()), self)
            action.triggered.connect(functools.partial(self.loadRecent, f))
            menu.addAction(action)

    def popLabelListMenu(self, point):
        self.menus.labelList.exec_(self.labelList.mapToGlobal(point))

    def validateLabel(self, label):
        # no validation
        if self._config['validate_label'] is None:
            return True

        for i in range(self.uniqLabelList.count()):
            label_i = self.uniqLabelList.item(i).text()
            if self._config['validate_label'] in ['exact', 'instance']:
                if label_i == label:
                    return True
            if self._config['validate_label'] == 'instance':
                m = re.match(r'^{}-[0-9]*$'.format(label_i), label)
                if m:
                    return True
        return False

    def editLabel(self, item=None):
        if not self.canvas.editing():
            return
        item = item if item else self.currentItem()
        text = self.labelDialog.popUp(item.text())
        if text is None:
            return
        if not self.validateLabel(text):
            self.errorMessage('Invalid label',
                              "Invalid label '{}' with validation type '{}'"
                              .format(text, self._config['validate_label']))
            return
        item.setText(text)
        self.setDirty()
        if not self.uniqLabelList.findItems(text, Qt.MatchExactly):
            self.uniqLabelList.addItem(text)
            self.uniqLabelList.sortItems()

    def fileSearchChanged(self):
        self.importDirImages(
            self.lastOpenDir,
            pattern=self.fileSearch.text(),
            load=False,
        )
        self.fileListWidget.update()

    def fileSelectionChanged(self):
        self.fileListWidgetP.clearSelection()

        self.bool_selection_changed = True

        items = self.fileListWidget.selectedItems()
        if not items:
            return
        item = items[0]

        if not self.mayContinue():
            return

        currIndex = self.imageList.index(str(item.text()))
        if currIndex < len(self.imageList):
            filename = self.imageList[currIndex]
            if filename:
                self.loadFile(filename)
                image = cv2.imread(filename,0)
                if image.shape[0]<=300:
                    self.max_size_spin.setValue(image.shape[0])
                    self.min_size_spin.setValue(image.shape[0])
                else: self.max_size_spin.setValue(300)

    def processedFilesSelectionChanged(self):
        self.fileListWidget.clearSelection()

        items = self.fileListWidgetP.selectedItems()
        if not items:
            return
        item = items[0]

        if not self.mayContinue():
            return

        currIndex = self.processedImageList.index(str(item.text()))
        if currIndex < len(self.processedImageList):
            filename = self.processedImageList[currIndex]
            if filename:
                self.loadFile(filename)

    # React to canvas signals.
    def shapeSelectionChanged(self, selected=False):
        if self._noSelectionSlot:
            self._noSelectionSlot = False
        else:
            shape = self.canvas.selectedShape
            if shape:
                item = self.labelList.get_item_from_shape(shape)
                item.setSelected(True)
            else:
                self.labelList.clearSelection()
        self.actions.delete.setEnabled(selected)
        self.actions.copy.setEnabled(selected)
        self.actions.edit.setEnabled(selected)
        self.actions.shapeLineColor.setEnabled(selected)
        self.actions.shapeFillColor.setEnabled(selected)

    def addLabel(self, shape):
        item = QtWidgets.QListWidgetItem(shape.label)
        item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
        item.setCheckState(Qt.Checked)
        self.labelList.itemsToShapes.append((item, shape))
        self.labelList.addItem(item)
        if not self.uniqLabelList.findItems(shape.label, Qt.MatchExactly):
            self.uniqLabelList.addItem(shape.label)
            self.uniqLabelList.sortItems()
        self.labelDialog.addLabelHistory(item.text())
        for action in self.actions.onShapesPresent:
            action.setEnabled(True)

    def remLabel(self, shape):
        item = self.labelList.get_item_from_shape(shape)
        self.labelList.takeItem(self.labelList.row(item))

    def loadShapes(self, shapes):
        for shape in shapes:
            self.addLabel(shape)
        self.canvas.loadShapes(shapes)

    def loadLabels(self, shapes):
        s = []
        for label, points, line_color, fill_color, shape_type in shapes:
            shape = Shape(label=label, shape_type=shape_type)
            for x, y in points:
                shape.addPoint(QtCore.QPoint(x, y))
            shape.close()
            s.append(shape)
            if line_color:
                shape.line_color = QtGui.QColor(*line_color)
            if fill_color:
                shape.fill_color = QtGui.QColor(*fill_color)
        self.loadShapes(s)

    def loadFlags(self, flags):
        self.flag_widget.clear()
        for key, flag in flags.items():
            item = QtWidgets.QListWidgetItem(key)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if flag else Qt.Unchecked)
            self.flag_widget.addItem(item)

    def saveLabels(self, filename):
        lf = LabelFile()

        def format_shape(s):
            return dict(
                label=s.label.encode('utf-8') if PY2 else s.label,
                line_color=s.line_color.getRgb()
                if s.line_color != self.lineColor else None,
                fill_color=s.fill_color.getRgb()
                if s.fill_color != self.fillColor else None,
                points=[(p.x(), p.y()) for p in s.points],
                shape_type=s.shape_type,
            )

        shapes = [format_shape(shape) for shape in self.labelList.shapes]
        flags = {}
        for i in range(self.flag_widget.count()):
            item = self.flag_widget.item(i)
            key = item.text()
            flag = item.checkState() == Qt.Checked
            flags[key] = flag
        try:
            imagePath = osp.relpath(
                self.imagePath, osp.dirname(filename))
            imageData = self.imageData if self._config['store_data'] else None
            if osp.dirname(filename) and not osp.exists(osp.dirname(filename)):
                os.makedirs(osp.dirname(filename))
            lf.save(
                filename=filename,
                shapes=shapes,
                imagePath=imagePath,
                imageData=imageData,
                imageHeight=self.image.height(),
                imageWidth=self.image.width(),
                lineColor=self.lineColor.getRgb(),
                fillColor=self.fillColor.getRgb(),
                otherData=self.otherData,
                flags=flags,
            )
            self.labelFile = lf
            items = self.fileListWidget.findItems(
                self.imagePath, Qt.MatchExactly
            )
            if len(items) > 0:
                if len(items) != 1:
                    raise RuntimeError('There are duplicate files.')
                items[0].setCheckState(Qt.Checked)
            # disable allows next and previous image to proceed
            # self.filename = filename
            return True
        except LabelFileError as e:
            self.errorMessage('Error saving label data', '<b>%s</b>' % e)
            return False

    def copySelectedShape(self):
        self.addLabel(self.canvas.copySelectedShape())
        # fix copy and delete
        self.shapeSelectionChanged(True)

    def labelSelectionChanged(self):
        item = self.currentItem()
        if item and self.canvas.editing():
            self._noSelectionSlot = True
            shape = self.labelList.get_shape_from_item(item)
            self.canvas.selectShape(shape)

    def labelItemChanged(self, item):
        shape = self.labelList.get_shape_from_item(item)
        label = str(item.text())
        if label != shape.label:
            shape.label = str(item.text())
            self.setDirty()
        else:  # User probably changed item visibility
            self.canvas.setShapeVisible(shape, item.checkState() == Qt.Checked)

    # Callback functions:

    def newShape(self):
        """Pop-up and give focus to the label editor.

        position MUST be in global coordinates.
        """
        items = self.uniqLabelList.selectedItems()
        text = None
        if items:
            text = items[0].text()
        if self._config['display_label_popup'] or not text:
            text = self.labelDialog.popUp(text)
        if text is not None and not self.validateLabel(text):
            self.errorMessage('Invalid label',
                              "Invalid label '{}' with validation type '{}'"
                              .format(text, self._config['validate_label']))
            text = None
        if text is None:
            self.canvas.undoLastLine()
            self.canvas.shapesBackups.pop()
        else:
            self.addLabel(self.canvas.setLastLabel(text))
            self.actions.editMode.setEnabled(True)
            self.actions.undoLastPoint.setEnabled(False)
            self.actions.undo.setEnabled(True)
            self.setDirty()

    def scrollRequest(self, delta, orientation):
        units = - delta * 0.1  # natural scroll
        bar = self.scrollBars[orientation]
        bar.setValue(bar.value() + bar.singleStep() * units)

    def setZoom(self, value):
        self.actions.fitWidth.setChecked(False)
        self.actions.fitWindow.setChecked(False)
        self.zoomMode = self.FIT_WINDOW
        self.zoomWidget.setValue(value)

    def addZoom(self, increment=10):
        self.setZoom(self.zoomWidget.value() + increment)

    def zoomRequest(self, delta, pos):
        canvas_width_old = self.canvas.width()

        units = delta * 0.1
        self.addZoom(units)

        canvas_width_new = self.canvas.width()
        if canvas_width_old != canvas_width_new:
            canvas_scale_factor = canvas_width_new / canvas_width_old

            x_shift = round(pos.x() * canvas_scale_factor) - pos.x()
            y_shift = round(pos.y() * canvas_scale_factor) - pos.y()

            self.scrollBars[Qt.Horizontal].setValue(
                self.scrollBars[Qt.Horizontal].value() + x_shift)
            self.scrollBars[Qt.Vertical].setValue(
                self.scrollBars[Qt.Vertical].value() + y_shift)

    def setFitWindow(self, value=True):
        if value:
            self.actions.fitWidth.setChecked(False)
        self.zoomMode = self.FIT_WINDOW if value else self.MANUAL_ZOOM
        self.adjustScale()

    def rotate_bound(self, image_cv, angle):
        # grab the dimensions of the image and then determine the
        # center
        (h, w) = image_cv.shape[:2]
        (cX, cY) = (w // 2, h // 2)

        # grab the rotation matrix (applying the negative of the
        # angle to rotate clockwise), then grab the sine and cosine
        # (i.e., the rotation components of the matrix)
        M = cv2.getRotationMatrix2D((cX, cY), -angle, 1.0)
        cos = np.abs(M[0, 0])
        sin = np.abs(M[0, 1])

        # compute the new bounding dimensions of the image
        nW = int((h * sin) + (w * cos))
        nH = int((h * cos) + (w * sin))

        # adjust the rotation matrix to take into account translation
        M[0, 2] += (nW / 2) - cX
        M[1, 2] += (nH / 2) - cY

        # perform the actual rotation and return the image
        return cv2.warpAffine(image_cv, M, (nW, nH))

    def noise_generator(self, image):
        '''Salt and perrer noize generator'''
        s_vs_p = 0.8
        amount = 0.07
        out = image
        # Generate Salt '1' noise
        num_salt = np.ceil(amount * image.size * s_vs_p)
        coords = [np.random.randint(0, i - 1, int(num_salt))
                  for i in image.shape]
        out[tuple(coords)] = 255
        # Generate Pepper '0' noise
        num_pepper = np.ceil(amount * image.size * (1. - s_vs_p))
        coords = [np.random.randint(0, i - 1, int(num_pepper))
                  for i in image.shape]
        out[tuple(coords)] = 0
        return out

    def flare_changed(self,img, darkness):
        w = img.shape[0]
        center_X = float(randint(1,100))/float(100)
        center_Y = float(randint(1,100))/float(100)

        center = (int(w * center_X), int(w * center_Y))
        back_gnd = np.ones((w, w, 4), np.uint8) * darkness

        flare_2_circle = cv2.circle(back_gnd, center, 2*w/5, (255,255,255), -1)
        flare_2_circle = cv2.blur(flare_2_circle, (321, 251), (1, 1))
        img = cv2.add(img,flare_2_circle)
        return img

    def remove_sample(self):
        dirpath = os.getcwd() + '/result/signs'
        items = self.fileListWidgetP.selectedItems()
        if not items:
            return
        item = items[0]
        currIndex = self.processedImageList.index(str(item.text()))
        if currIndex < len(self.processedImageList):
            filename = self.processedImageList[currIndex]
            if filename:
                self.processedImageList.remove(filename)
                self.fileListWidgetP.takeItem(self.fileListWidgetP.row(item))
                os.remove(filename)
        else: self.actions.remove_sample.setEnabled(False)
        self.fileSearchP.setPlaceholderText('Search Filename out of {} picts'.format(len(os.listdir(dirpath))))

    def views(self, img, dir=None):

        try:
            size = img.shape[0]
            pts1 = np.float32([[0, 0], [size, 0], [0, size], [size, size]])
            if self.b_dist_chb.isChecked() and dir == 'b': # bottom
                pts2 = np.float32([[0, 0], [size, 0], [size * self.b_dist_spin.value()*0.01, size], [size * (1-self.b_dist_spin.value()*0.01), size]])
            elif self.l_dist_chb.isChecked() and dir == 'l': # left
                pts2 = np.float32([[0, size * self.l_dist_spin.value()*0.01], [size, 0], [0, size * (1-self.l_dist_spin.value()*0.01)], [size, size]])
            elif self.r_dist_chb.isChecked() and dir == 'r': # right
                pts2 = np.float32([[0, 0], [size, size * self.r_dist_spin.value()*0.01], [0, size], [size, size * (1-self.r_dist_spin.value()*0.01)]])

            M = cv2.getPerspectiveTransform(pts1, pts2)
            dst = cv2.warpPerspective(img, M, (size, size))
            return dst
        except UnboundLocalError: pass

    def generate_random_lines(self, imshape, slant, drop_length):
        drops = []
        for i in range(200):  ## If You want heavy rain, try increasing this
            if slant < 0:
                x = np.random.randint(slant, imshape[1])
            else:
                x = np.random.randint(0, imshape[1] - slant)
            y = np.random.randint(0, imshape[0] - drop_length)
            drops.append((x, y))
        return drops

    def add_rain(self, image, droplength):
        imshape = image.shape
        slant_extreme = 4 #angle
        slant = np.random.randint(-slant_extreme, slant_extreme)
        drop_length = droplength #20
        drop_width = 1
        drop_color = (220, 220, 220)
        rain_drops = self.generate_random_lines(imshape, slant, drop_length)

        for rain_drop in rain_drops:
            cv2.line(image, (rain_drop[0], rain_drop[1]), (rain_drop[0] + slant, rain_drop[1] + drop_length),
                     drop_color,
                     drop_width)

        return image

    def generate_button_check_enabled(self):

        self.pseudo_qt_list = self.groupBox.findChildren(QtWidgets.QCheckBox)
        self.pseudo_qt_list = list(self.pseudo_qt_list)
        tmp = []

        for i in range(0,len(self.pseudo_qt_list),1):
            tmp.append(self.pseudo_qt_list[i].isChecked())
        tmp = set(tmp)

        if len(tmp) == 2 or list(tmp)[0]:
            self.generate_button.setEnabled(True)
            self.preview_button.setEnabled(True)
        else:
            self.generate_button.setEnabled(False)
            self.preview_button.setEnabled(False)
            self.preview_button.setStyleSheet("color: #aaa;")  # properly gray

    def generate_button_method(self):
        self.signs_flag = True

        self.dialog.show()

        self.myQThread = QtCore.QThread()
        self.myQThread.start()

        self.myQThread.finished.connect(self.myQThread.deleteLater)
        self.myQThread.finished.connect(self.result_pictset_fileListWidget)
        self.myQThread.finished.connect(self.thread_completed)

        self.myWorker = GenericWorker(self.generate_signs)
        self.myWorker.finished.connect(self.myQThread.quit)
        self.myWorker.value_changed.connect(self.set_pb_value)
        self.myWorker.moveToThread(self.myQThread)

        self.myWorker.start.emit("hello")

    def thread_completed(self):
        if self.dialog.stop_button.isEnabled():
            self.dialog.timer.stop()
            self.dialog.text_hint.setText("Completed")
            self.dialog.stop_button.setEnabled(False)

    def stop_button_handler(self):
        self.flag =  True
        self.dialog.timer.stop()
        self.dialog.text_hint.setText("{} samples have been successfully generated".
                                          format((self.pictures_iter + 1) if self.signs_flag else (self.samples_iter + 1)))

    def close_button_handler(self):
        self.flag =  True
        self.dialog.text_hint.setText("{} samples have been successfully generated".
                                      format((self.pictures_iter) if self.signs_flag else (self.samples_iter)))
        self.signs_flag = False
        self.timer_singleshot.start(1000)

    def thread_cleanup(self):
        self.dialog.close()
        self.actions.create_samples.setEnabled(True)
        self.flag = False

    def preview_button_color(self):
        if self.generate_button.isEnabled():
            self.preview_button.setStyleSheet("color: black;")  # properly gray
        else:
            self.preview_button.setStyleSheet("color: #aaa;")  # properly gray

    def set_pb_value(self):
        self.dialog.progress_bar.setFormat("{}/{}".format(self.pictures_iter,self.pictures_total))
        self.dialog.progress_bar.setValue(round((float(self.pictures_iter)/float(self.pictures_total))*100))
        self.fileSearchP.setPlaceholderText('Search Filename out of {} picts'.format(self.pictures_iter))


    def preview_button_method(self):

        self.usual_mode_flag = False
        self.canvas.setEnabled(False)
        items = self.fileListWidget.selectedItems()
        if not items: return
        item = items[0]
        if not self.mayContinue(): return

        currIndex = self.imageList.index(str(item.text()))
        if currIndex < len(self.imageList):
            filename = self.imageList[currIndex]

        if self.preview_button.isChecked():
            self.preview_flag = True

            self.gb1.setEnabled(False)
            self.angleGB.setEnabled(False)
            self.sizeGB.setEnabled(False)
            self.brightness_contrast_kernelSize.setEnabled(False)
            self.ChBoxesButtonsGB.setEnabled(False)
            self.generate_button.setEnabled(False)
            self.fileListWidget.setEnabled(False)
            self.fileSearch.setEnabled(False)
        else:
            self.preview_flag = False

            self.gb1.setEnabled(True)
            self.angleGB.setEnabled(True)
            self.sizeGB.setEnabled(True)
            self.brightness_contrast_kernelSize.setEnabled(True)
            self.ChBoxesButtonsGB.setEnabled(True)
            self.generate_button.setEnabled(True)
            self.fileListWidget.setEnabled(True)
            self.fileSearch.setEnabled(True)

            if not self.usual_mode_flag: self.loadFile(filename)
            return True

        self.calculate_pict_among()

        if filename:
            self.tmp_picture = self.make_transparent(filename)

        """PICTURES FOR GRID"""
        if self.l_dist_chb.isChecked():
            self.l_dist_pict = self.views(self.tmp_picture, dir="l")
            self.picture_dict.update({"Left perspective": self.l_dist_pict})
        else:
            try:
                del self.picture_dict["Left perspective"]
            except KeyError: pass

        if self.r_dist_chb.isChecked():
            self.r_dist_pict = self.views(self.tmp_picture, dir="r")
            self.picture_dict.update({"Right perspective": self.r_dist_pict})
        else:
            try:
                del self.picture_dict["Right perspective"]
            except KeyError: pass

        if self.b_dist_chb.isChecked():
            self.b_dist_pict = self.views(self.tmp_picture, dir="b")
            self.picture_dict.update({"Bot perspective": self.b_dist_pict})
        else:
            try:
                del self.picture_dict["Bot perspective"]
            except KeyError: pass

        if self.min_angle_chb.isChecked():
            self.min_angle_pict = self.rotate_bound(self.tmp_picture, self.min_angle_spin.value().__neg__())
            self.picture_dict.update({"Min rotation angle": self.min_angle_pict})
        else:
            try:
                del self.picture_dict["Min rotation angle"]
            except KeyError: pass

        if self.max_angle_chb.isChecked():
            self.max_angle_pict = self.rotate_bound(self.tmp_picture, self.max_angle_spin.value())
            self.picture_dict.update({"Max rotation angle": self.max_angle_pict})

        else:
            try:
                del self.picture_dict["Max rotation angle"]
            except KeyError: pass

        if self.min_size_chb.isChecked():
            if not self.min_size_spin.value() % self.step_size_spin.value():
                self.min_size_spin.setValue(
                    math.ceil(self.step_size_spin.value() * (self.min_size_spin.value() / self.step_size_spin.value())))
            if self.min_size_spin.value() > self.max_size_spin.value():
                self.min_size_spin.setValue(self.max_size_spin.value())
            self.min_size_pict = cv2.resize(self.tmp_picture, (self.min_size_spin.value(), self.min_size_spin.value()))
            self.picture_dict.update({"Min image size": self.min_size_pict})
        else:
            try:
                del self.picture_dict["Min image size"]
            except KeyError: pass

        if self.max_size_chb.isChecked():
            self.max_size_pict = cv2.resize(self.tmp_picture, (self.max_size_spin.value(), self.max_size_spin.value()))
            self.picture_dict.update({"Max image size": self.max_size_pict})
        else:
            try:
                del self.picture_dict["Max image size"]
            except KeyError: pass

        if self.brightness_chb.isChecked():
            self.brightned_pict = self.brightness_changed(self.tmp_picture)
            self.picture_dict.update({"Brightness": self.brightned_pict})
        else:
            try:
                del self.picture_dict["Brightness"]
            except KeyError: pass

        if self.contrast_chb.isChecked():
            self.contrasted_pict = self.contrast_changed(self.tmp_picture)
            self.picture_dict.update({"Contrast": self.contrasted_pict})
        else:
            try:
                del self.picture_dict["Contrast"]
            except KeyError: pass

        if self.flared_chb.isChecked():
            self.flared_pict = self.flare_changed(self.tmp_picture, 0)
            self.picture_dict.update({"Flared": self.flared_pict})
        else:
            try:
                del self.picture_dict["Flared"]
            except KeyError: pass

        if self.kernel_chb.isChecked():
            if not self.kernel_size_spin.value() % 2:
                self.kernel_size_spin.setValue(math.ceil(self.kernel_size_spin.value() - 1))
            self.blured_pict = cv2.blur(
                self.tmp_picture,
                (self.kernel_size_spin.value(), self.kernel_size_spin.value()),
                (1, 1))
            self.picture_dict.update({"Kernel size": self.blured_pict})
        else:
            try:
                del self.picture_dict["Kernel size"]
            except KeyError: pass

        if self.noized_chb.isChecked():
            if not self.picture_dict.has_key("Noized"):
                self.noized_pict = self.add_rain(self.tmp_picture, self.tmp_picture.shape[0]/20)
                self.picture_dict.update({"Noized": self.noized_pict})
                self.noized.setEnabled(True)
        else:
            try:
                del self.picture_dict["Noized"]
                self.noized.setEnabled(False)
            except KeyError: pass

        """~PICTURES FOR GRID~"""
        fig = plt.figure(figsize=(14, 9))
        columns = 4
        rows = 3
        ax = []
        keys = self.picture_dict.keys()

        for i in range(columns * rows):
            try:
                ax.append(fig.add_subplot(rows, columns, i + 1))
                ax[-1].set_title(keys[i])  # set title
                plt.imshow(self.picture_dict.get(keys[i]))
                plt.xticks((0, self.picture_dict.get(keys[i]).shape[0]))
                plt.yticks((0, self.picture_dict.get(keys[i]).shape[1]))
            except IndexError:
                plt.box('off')
                plt.axis('off')
                pass

        plt.subplots_adjust(left=0.05, right=0.95, wspace=0.2, hspace=0.4, top=0.95, bottom=0.05)
        plt.savefig("self.picture_dict.png", dpi=None, facecolor='w', edgecolor='w', papertype=None,
        transparent=False, bbox_inches=None, pad_inches=0.1, frameon=None, metadata=None)

        tmp_pict = cv2.imread("self.picture_dict.png", cv2.IMREAD_UNCHANGED)
        qimg = qimage2ndarray.array2qimage(tmp_pict)

        self.canvas.loadPixmap(QtGui.QPixmap.fromImage(qimg))
        self.setClean()
        self.canvas.setEnabled(True)
        self.adjustScale(initial=False)
        self.paintCanvas()
        self.toggleActions(True)
        self.status("Loaded %s" % osp.basename(str(filename)))

    def brightness_changed(self, img):
        w = img.shape[0]
        back_gnd = np.ones((w, w, 3), np.uint8) * int(self.brightness_spin.value() * float(2.5))
        b_channel, g_channel, r_channel = cv2.split(back_gnd)
        alpha_channel = np.ones(b_channel.shape, dtype=b_channel.dtype) * 255
        back_gnd_BGRA = cv2.merge((b_channel, g_channel, r_channel, alpha_channel))

        zeros = np.array([0,0,0,0])

        for row in range(0,w,1):
            for col in range(0,w,1):
                if set(img[row][col]) == set(zeros):
                    back_gnd_BGRA[row][col] = zeros

        img = cv2.addWeighted(img, 0.4, back_gnd_BGRA, 0.6, 0)
        return img

    def set_brightness_transparent(self,img):
        w = img.shape[0]
        back_gnd = np.ones((w, w, 3), np.uint8) * int(self.brightness_spin.value() * float(2.5))

        b_channel, g_channel, r_channel = cv2.split(back_gnd)
        alpha_channel = np.ones(b_channel.shape, dtype=b_channel.dtype) * 255  # creating a dummy alpha channel image.
        back_gnd_BGRA = cv2.merge((b_channel, g_channel, r_channel, alpha_channel))

        zeros = np.array([0, 0, 0, 0])

        for row in range(0, w, 1):
            for col in range(0, w, 1):
                if set(img[row][col]) == set(zeros):
                    back_gnd_BGRA[row][col] = zeros

        img = cv2.addWeighted(img, 0.1, back_gnd_BGRA, 0.9, 0)
        return img

    def contrast_changed(self,img):
        hist, bins = np.histogram(img.flatten(), 256, [0, 256])
        cdf = hist.cumsum()

        cdf_m = np.ma.masked_equal(cdf, 0)
        cdf_m = (cdf_m - cdf_m.min()) * self.contrast_spin.value()*2.5 / (cdf_m.max() - cdf_m.min())
        cdf = np.ma.filled(cdf_m, 0).astype('uint8')
        img2 = cdf[img]
        return img2

    def realtime_preview(self,action=None,angle=None,px=None,dir=None):

        self.usual_mode_flag = True
        if self.preview_flag: return True
        self.calculate_pict_among()

        self.canvas.setEnabled(False)
        items = self.fileListWidget.selectedItems()
        if not items: return
        item = items[0]
        if not self.mayContinue(): return

        currIndex = self.imageList.index(str(item.text()))
        if currIndex < len(self.imageList):
            filename = self.imageList[currIndex]
            if filename:
                self.tmp_picture = self.make_transparent(filename)

        if action == 'rotate':
            if self.min_angle_chb.isChecked():
                self.tmp_picture = self.rotate_bound(self.tmp_picture, angle)
            if self.max_angle_chb.isChecked():
                self.tmp_picture = self.rotate_bound(self.tmp_picture, angle)

        elif action == 'resize':
            if not self.min_size_spin.value()%self.step_size_spin.value():
                self.min_size_spin.setValue(
                    math.ceil(self.step_size_spin.value()*(self.min_size_spin.value()/self.step_size_spin.value())))
            if self.min_size_spin.value() > self.max_size_spin.value():
                self.min_size_spin.setValue(self.max_size_spin.value())
            if self.min_size_chb.isChecked():
                self.tmp_picture = cv2.resize(self.tmp_picture,(px,px))
            if self.max_size_chb.isChecked():
                self.tmp_picture = cv2.resize(self.tmp_picture,(px,px))

        elif action == 'noized':
            if self.noized_chb.isChecked():
                self.tmp_picture = self.add_rain(self.tmp_picture,self.tmp_picture.shape[0]/20)
            self.noized.setEnabled(not self.noized.isEnabled())
        elif action == 'flared':
            if self.flared_chb.isChecked():self.tmp_picture = self.flare_changed(self.tmp_picture,0)
            self.flared.setEnabled(not self.flared.isEnabled())
        elif action == '3d':
            self.tmp_picture = self.views(self.tmp_picture,dir=dir)
        elif action == 'blur':
            if not self.kernel_size_spin.value()%2:
                self.kernel_size_spin.setValue(math.ceil(self.kernel_size_spin.value()-1))
            if self.kernel_chb.isChecked():
                self.tmp_picture = cv2.blur(
                    self.tmp_picture,
                    (self.kernel_size_spin.value(),self.kernel_size_spin.value()),
                    (1,1))
        elif action == 'bright':
            if self.brightness_chb.isChecked():
                self.tmp_picture = self.brightness_changed(self.tmp_picture)
        elif action == 'contrast':
            if self.contrast_chb.isChecked():
                if filename:
                    self.tmp_picture = cv2.imread(filename)
                self.tmp_picture = self.contrast_changed(self.tmp_picture)

                b_channel, g_channel, r_channel = cv2.split(self.tmp_picture)
                alpha_channel = np.ones(b_channel.shape,
                                        dtype=b_channel.dtype) * 255  # creating a dummy alpha channel image.
                self.tmp_picture = cv2.merge((b_channel, g_channel, r_channel, alpha_channel))

        try:
            qimg = qimage2ndarray.array2qimage(self.tmp_picture)
        except ValueError:
            qimg = qimage2ndarray.array2qimage(self.make_transparent(filename))

        self.canvas.loadPixmap(QtGui.QPixmap.fromImage(qimg))
        self.setClean()
        self.canvas.setEnabled(True)
        self.adjustScale(initial=False)
        self.paintCanvas()
        self.toggleActions(True)
        self.status("Loaded %s" % osp.basename(str(filename)))

        self.preview_button.setStyleSheet("color: green;")
        self.timer_preview_color.start(1000)

    def yolo_coefs(self, dir, cls_num, size, bg_rows, bg_cols, x, y):
        file = open(dir + '/img{}.txt'.format(self.samples_iter), "a")
        resize = float(size * 1.1)
        delta = float(resize - size) / 2

        obj_c_X = (float(x - delta) + float(resize) / 2) / float(bg_cols)
        obj_c_Y = (float(y - delta) + float(resize) / 2) / float(bg_rows)
        obj_w_X = float(resize) / float(bg_cols)
        obj_w_Y = float(resize) / float(bg_rows)
        file.write('{} {} {} {} {}\n'.format(cls_num, obj_c_X, obj_c_Y, obj_w_X, obj_w_Y))
        file.close()

    def make_transparent(self, picture):
        img = cv2.imread(picture)

        b_channel, g_channel, r_channel = cv2.split(img)
        alpha_channel = np.ones(b_channel.shape, dtype=b_channel.dtype) * 255  # creating a dummy alpha channel image.
        img = cv2.merge((b_channel, g_channel, r_channel, alpha_channel))
        return img

    def transparentOverlay(self, src, overlay, pos=(0, 0), scale=1):
        """
        :param src: Input Color Background Image
        :param overlay: transparent Image (BGRA)
        :param pos:  position where the image to be blit.
        :param scale : scale factor of transparent image.
        :return: Resultant Image
        """
        overlay = cv2.resize(overlay, (0, 0), fx=scale, fy=scale)
        h, w, _ = overlay.shape  # Size of foreground
        rows, cols, _ = src.shape  # Size of background Image
        y, x = pos[0], pos[1]  # Position of foreground/overlay image

        # loop over all pixels and apply the blending equation
        for i in range(h):
            for j in range(w):
                if x + i >= rows or y + j >= cols:
                    continue
                alpha = float(overlay[i][j][3] / 255.0)  # read the alpha channel
                src[x + i][y + j] = alpha * overlay[i][j][:3] + (1 - alpha) * src[x + i][y + j]
        return src

    def loadPascalXMLByFilename(self, xmlPath):
        if self.filePath is None:
            return
        if os.path.isfile(xmlPath) is False:
            return

        self.set_format(FORMAT_PASCALVOC)

        tVocParseReader = PascalVocReader(xmlPath)
        shapes = tVocParseReader.getShapes()
        self.loadLabels(shapes)
        self.canvas.verified = tVocParseReader.verified


    def generation_settings(self):
        self.groupBox.setVisible(not self.groupBox.isVisible())
        self.calculate_pict_among()

    def set_format(self, save_format):
        self.actions.save_format.setText(FORMAT_YOLO)

        if save_format == FORMAT_PASCALVOC:
            self.actions.save_format.setText(FORMAT_PASCALVOC)
            self.actions.save_format.setIcon(newIcon("format_voc"))
            self.usingPascalVocFormat = True
            self.usingYoloFormat = False
            # LabelFile.suffix = XML_EXT

        elif save_format == FORMAT_YOLO:
            self.actions.save_format.setText(FORMAT_YOLO)
            self.actions.save_format.setIcon(newIcon("format_yolo"))
            self.usingPascalVocFormat = False
            self.usingYoloFormat = True
            # LabelFile.suffix = TXT_EXT

    def change_format(self):
        if self.usingPascalVocFormat:
            self.set_format(FORMAT_YOLO)
        elif self.usingYoloFormat:
            self.set_format(FORMAT_PASCALVOC)

    def openAnnotationDialog(self, _value=False, dirpath=None):
        if not self.mayContinue():
            return

        defaultOpenDirPath = dirpath if dirpath else '.'
        if self.lastOpenDir and osp.exists(self.lastOpenDir):
            defaultOpenDirPath = self.lastOpenDir
        else:
            defaultOpenDirPath = osp.dirname(self.filename) \
                if self.filename else '.'

        targetDirPath = str(QtWidgets.QFileDialog.getExistingDirectory(
            self, '%s - Open Directory' % __appname__, defaultOpenDirPath,
                  QtWidgets.QFileDialog.ShowDirsOnly |
                  QtWidgets.QFileDialog.DontResolveSymlinks))

        if not targetDirPath: return True

        new_path, ok = QtWidgets.QInputDialog.getText(
            self, 'Change annotation file', 'Enter new <path>{}</path>',
            QtWidgets.QLineEdit.Normal, "Enter absolute path without tags")

        if not ok and new_path == '': return True
        if new_path.endswith('/'): new_path = new_path[0:len(new_path) - 1]

        for xml_file in glob.glob(targetDirPath + '/*.xml'):

            content = open(xml_file).read()
            folder = re.findall('<folder>(.*)</folder>', content)
            folder_xml = "<folder>{}</folder>".format(folder[0])

            filename = re.findall('<filename>(.*)</filename>', content)

            path = re.findall('<path>(.*)</path>', content)
            path_xml = '<path>{}</path>'.format(path[0])

            new_content = content.replace(folder_xml,"<folder>{}</folder>".format(osp.basename(new_path)))
            new_content = new_content.replace(path_xml, '<path>{}</path>'.format(new_path + '/' + filename[0]))

            with open(xml_file, "w") as f:
                f.write(new_content)

    def create_samples_button(self):

        if not self.signs_dir:
            self.signs_dir = str(QtWidgets.QFileDialog.getExistingDirectory(
                self, '%s - Open directory with prepared signs' % __appname__, os.getcwd(),
                      QtWidgets.QFileDialog.ShowDirsOnly |
                      QtWidgets.QFileDialog.DontResolveSymlinks))
        if not self.signs_dir: return

        if not self.dataset_dir:
            self.dataset_dir = str(QtWidgets.QFileDialog.getExistingDirectory(
                self, '%s - Open directory with backgroud pictures' % __appname__, os.getcwd(),
                      QtWidgets.QFileDialog.ShowDirsOnly |
                      QtWidgets.QFileDialog.DontResolveSymlinks))

        if not self.dataset_dir: return

        self.dialog.show()

        self.csQThread1 = QtCore.QThread()
        self.csQThread1.finished.connect(self.csQThread1.deleteLater)

        self.csWorker1 = GenericWorker(self.create_samples)

        self.csWorker1.moveToThread(self.csQThread1)
        self.csWorker1.value_changed.connect(self.create_samples_set_pb_value)

        self.csQThread1.start()
        self.csWorker1.start.emit("h")
        self.csWorker1.finished.connect(self.csQThread1.quit)

    def create_samples_set_pb_value(self):
        self.samples_iter += 1
        self.dialog.progress_bar.setFormat("{}/{}".format(self.samples_iter,self.samples_total))
        self.dialog.progress_bar.setValue(round((float(self.samples_iter)/float(self.samples_total))*100))

    def create_samples(self):

        self.samples_total = len(os.listdir(self.dataset_dir))

        result_dir = os.getcwd() + "/result"
        images_dir = result_dir + "/images"

        if not os.path.exists(result_dir + "/voc_coefs"): os.makedirs(result_dir + "/voc_coefs")
        if not os.path.exists(result_dir + "/yolo_coefs"): os.makedirs(result_dir + "/yolo_coefs")
        if not os.path.exists(images_dir): os.mkdir(images_dir)

        self.samples_iter = 0

        if len(os.listdir(result_dir + "/voc_coefs")) != 0:
            os.system('rm -rf {}/*'.format(result_dir + "/voc_coefs"))

        if len(os.listdir(result_dir + "/yolo_coefs")) != 0:
            os.system('rm -rf {}/*'.format(result_dir + "/yolo_coefs"))

        if len(os.listdir(images_dir)) != 0:
            os.system('rm -rf {}/*'.format(images_dir))

        for bg_template in glob.glob(self.dataset_dir + '/*.png'):

            if self.flag: return True

            back_ground_picture = cv2.imread("{}".format(bg_template),cv2.IMREAD_UNCHANGED)
            br, bc,_ = back_ground_picture.shape
            i = randint(1, 3)
            depth = 1 if len(back_ground_picture.shape) == 1 else 3

            imageShape = [br, bc, depth]

            imagePath = images_dir + "/img{}.png".format(self.samples_iter)

            imgFolderPath = os.path.dirname(imagePath)
            imgFolderName = os.path.split(imgFolderPath)[-1]
            imgFileName = os.path.basename(imagePath)

            writer = PascalVocWriter(imgFolderName, imgFileName, imageShape, localImgPath=imagePath)

            if i == 1:

                file = choice(os.listdir(self.signs_dir))
                picture = cv2.imread(self.signs_dir + "/{}".format(file),cv2.IMREAD_UNCHANGED)
                yolo_class = file[1:3]
                print(yolo_class)

                s = picture.shape[0]
                x = randint(0, bc - s)
                y = randint(0, br - s)

                if self.usingYoloFormat:
                    self.yolo_coefs(result_dir + "/yolo_coefs", yolo_class,s,br,bc,x,y)
                else:
                    resize = int(s * 1.1)
                    delta = int(resize - s) / 2

                    xmin = int(round(x - delta))
                    ymin = int(round(y - delta))
                    xmax = int(round(x + resize))
                    ymax = int(round(y + resize))
                    label = "sign{}".format(yolo_class)

                    writer.addBndBox(xmin, xmax, ymin, ymax, label, 0)

                result = self.transparentOverlay(back_ground_picture,picture,(x,y),1)

            if i == 2:
                for iter in range(1,3):

                    file = choice(os.listdir(self.signs_dir))
                    picture = cv2.imread(self.signs_dir + "/{}".format(file), cv2.IMREAD_UNCHANGED)
                    yolo_class = file[1:3]

                    s = picture.shape[0]
                    if iter == 1:
                        x = randint(0, (bc / 2) - int(1.3 * s))
                    if iter == 2:
                        x = randint((bc / 2) + s, bc - s)
                    y = randint(0, br - int(1.3 * s))

                    if self.usingYoloFormat:
                        self.yolo_coefs(result_dir + "/yolo_coefs", yolo_class, s, br, bc, x, y)
                    else:
                        resize = float(s * 1.1)
                        delta = float(resize - s) / 2

                        xmin = int(round(x - delta))
                        ymin = int(round(y - delta))
                        xmax = int(round(x + resize))
                        ymax = int(round(y + resize))
                        label = "sign{}".format(yolo_class)

                        writer.addBndBox(xmin, xmax, ymin, ymax, label, 0)
                    result = self.transparentOverlay(back_ground_picture,picture,(x,y),1)

            if i == 3:
                for iter in range(1,4):

                    file = choice(os.listdir(self.signs_dir))
                    picture = cv2.imread(self.signs_dir + "/{}".format(file), cv2.IMREAD_UNCHANGED)
                    yolo_class = file[1:3]
                    s = picture.shape[0]

                    if iter == 1:
                        x = randint(0, bc / 3 - int(1.3 * s))
                    if iter == 2:
                        x = randint((bc / 3) + s, (2 * bc / 3) - s)
                    if iter == 3:
                        x = randint((2 * bc / 3) + s, bc - s)

                    y = randint(0, br - s)

                    if self.usingYoloFormat:
                        self.yolo_coefs(result_dir + "/yolo_coefs", yolo_class, s, br, bc, x, y)
                    else:
                        resize = float(s * 1.1)
                        delta = float(resize - s) / 2

                        xmin = int(round(x - delta))
                        ymin = int(round(y - delta))
                        xmax = int(round(x + resize))
                        ymax = int(round(y + resize))
                        label = "sign{}".format(yolo_class)
                        writer.addBndBox(xmin, xmax, ymin, ymax, label, 0)

                    result = self.transparentOverlay(back_ground_picture,picture,(x,y),1)
            try:
                cv2.imwrite(images_dir + '/img%d.png'%self.samples_iter, result)
                writer.save(targetFile=result_dir + "/voc_coefs/img{}".format(self.samples_iter))

            except Exception as e:
                ok = QtWidgets.QMessageBox.Abort
                QtWidgets.QMessageBox.warning(self, 'Attention', str(e), ok)
                return False

            self.csWorker1.value_changed.emit(1)
            if self.flag: return True
    
    
    def generate_signs(self):
        path = os.getcwd() + '/result/signs'

        if osp.exists(path) and len(os.listdir(path)) != 0:
            os.system('rm -rf {}'.format(path))
            os.makedirs(path)
        else:
            os.makedirs(path)

        self.pictures_iter = 0
        '''RESIZING'''
        if not self.min_size_chb.isChecked() and not self.max_size_chb.isChecked():
            for picture in glob.glob('{}/*.png'.format(osp.dirname(self.imageList[0]))):
                size = cv2.imread(picture)
                size = size.shape[0]
                self.basename = osp.basename(picture)
                self.filename = osp.splitext(self.basename)[0]
                sign = self.make_transparent(picture)
                resized = cv2.resize(sign, (size, size))
                cv2.imwrite('{}/{}-{}px.png'.format(path, self.filename, size), resized)

                self.pictures_iter += 1
                self.myWorker.value_changed.emit(1)

                if self.flag: return True

        if self.min_size_chb.isChecked() or self.max_size_chb.isChecked():

            for picture in glob.glob('{}/*.png'.format(osp.dirname(self.imageList[0]))):

                self.basename = osp.basename(picture)
                self.filename = osp.splitext(self.basename)[0]
                sign = self.make_transparent(picture)

                for size in range(self.min_size_spin.value(), self.max_size_spin.value() + 1,self.step_size_spin.value()):
                        resized = cv2.resize(sign, (size,size))
                        try:
                            cv2.imwrite('{}/{}-{}px.png'.format(path,self.filename,size),resized)

                        except Exception as e:
                            ok = QtWidgets.QMessageBox.Abort
                            QtWidgets.QMessageBox.warning(self, 'Attention', str(e), ok)
                            return False

                        self.pictures_iter += 1
                        self.myWorker.value_changed.emit(1)

                        if self.flag: return True

        '''CONTRASTING'''
        if self.contrast_chb.isChecked():
            for picture in glob.glob('{}/*.png'.format(path)):
                self.basename = os.path.basename(picture)
                self.filename = os.path.splitext(self.basename)[0]

                sign = cv2.imread(picture, cv2.IMREAD_COLOR)

                contrasted = self.contrast_changed(sign)

                b_channel, g_channel, r_channel = cv2.split(contrasted)
                alpha_channel = np.ones(b_channel.shape,
                                        dtype=b_channel.dtype) * 255  # creating a dummy alpha channel image.
                contrasted = cv2.merge((b_channel, g_channel, r_channel, alpha_channel))
                try:
                    cv2.imwrite('{}/{}-contrasted.png'.format(path, self.filename), contrasted)

                except Exception as e:
                    ok = QtWidgets.QMessageBox.Abort
                    QtWidgets.QMessageBox.warning(self, 'Attention', str(e),ok)
                    return False

                self.pictures_iter += 1
                self.myWorker.value_changed.emit(1)

                if self.flag: return True

        '''ROTATING'''
        if self.min_angle_chb.isChecked() or self.max_angle_chb.isChecked():
            if self.min_angle_chb.isChecked():
                min = self.min_angle_spin.value().__neg__()
            else: min = 0
            if self.max_angle_chb.isChecked():
                max = self.max_angle_spin.value()
            else: max = 0

            for picture in glob.glob('{}/*.png'.format(path)):
                self.basename = osp.basename(picture)
                self.filename = osp.splitext(self.basename)[0]
                sign = cv2.imread(picture, cv2.IMREAD_UNCHANGED)

                for angle in range(min, max + 1, self.step_angle_spin.value()):

                    if not angle:
                        continue
                    rotated = self.rotate_bound(sign, angle)
                    try:
                        cv2.imwrite('{}/{}-angle{}.png'.format(path,self.filename,angle), rotated)

                    except Exception as e:
                        ok = QtWidgets.QMessageBox.Abort
                        QtWidgets.QMessageBox.warning(self, 'Attention', str(e), ok)
                        return False

                    self.pictures_iter += 1
                    self.myWorker.value_changed.emit(1)

                    if self.flag: return True

        '''BLURING'''
        if self.kernel_chb.isChecked():
            for picture in glob.glob('{}/*.png'.format(path)):
                self.basename = os.path.basename(picture)
                self.filename = os.path.splitext(self.basename)[0]

                sign = cv2.imread(picture, cv2.IMREAD_UNCHANGED)
                for kernel in range(1, self.kernel_size_spin.value()+1, 2):
                    if kernel == 1 or sign.shape[0] <= 40:
                        continue
                    if sign.shape[0] <= 60 and kernel >= 5:
                        continue
                    if sign.shape[0] <= 150 and kernel >= 7:
                        continue
                    blured = cv2.blur(sign, (kernel, kernel), (1, 1))
                    try:
                        cv2.imwrite('{}/{}-kernel-{}.png'.format(path,self.filename,kernel), blured)

                    except Exception as e:
                        ok = QtWidgets.QMessageBox.Abort
                        QtWidgets.QMessageBox.warning(self, 'Attention', str(e), ok)
                        return False

                    self.pictures_iter += 1
                    self.myWorker.value_changed.emit(1)

                    if self.flag: return True


        '''PERSPECTIVE TRANSFORM'''
        if self.r_dist_chb.isChecked() or self.l_dist_chb.isChecked() or self.b_dist_chb.isChecked():
            for picture in glob.glob('{}/*.png'.format(path)):
                self.basename = os.path.basename(picture)
                self.filename = os.path.splitext(self.basename)[0]

                sign = cv2.imread(picture, cv2.IMREAD_UNCHANGED)

                for direction in self.directions:

                    perspective_transformed = self.views(sign, direction)
                    try:
                        cv2.imwrite('{}/{}-{}.png'.format(path,self.filename,direction),perspective_transformed)
                    except Exception as e:
                        ok = QtWidgets.QMessageBox.Abort
                        QtWidgets.QMessageBox.warning(self, 'Attention', str(e), ok)
                        return False

                    self.pictures_iter += 1
                    self.myWorker.value_changed.emit(1)

                    if self.flag: return True

        '''BRIGHTING'''
        if self.brightness_chb.isChecked():
            for picture in glob.glob('{}/*.png'.format(path)):
                self.basename = os.path.basename(picture)
                self.filename = os.path.splitext(self.basename)[0]

                sign = cv2.imread(picture, cv2.IMREAD_UNCHANGED)

                brightned = self.brightness_changed(sign)
                try:
                    cv2.imwrite('{}/{}-brightned.png'.format(path, self.filename), brightned)

                except Exception as e:
                    ok = QtWidgets.QMessageBox.Abort
                    QtWidgets.QMessageBox.warning(self, 'Attention', str(e),ok)
                    return False

                self.pictures_iter += 1
                self.myWorker.value_changed.emit(1)

                if self.flag: return True


        '''FLARED'''
        if self.flared_chb.isChecked():
            for picture in glob.glob('{}/*.png'.format(path)):
                self.basename = os.path.basename(picture)
                self.filename = os.path.splitext(self.basename)[0]

                sign = cv2.imread(picture, cv2.IMREAD_UNCHANGED)

                flared = self.flare_changed(sign, 0)
                try:
                    cv2.imwrite('{}/{}-flared.png'.format(path, self.filename), flared)
                except Exception as e:
                    ok = QtWidgets.QMessageBox.Abort
                    QtWidgets.QMessageBox.warning(self, 'Attention', str(e),ok)
                    return False

                self.pictures_iter += 1
                self.myWorker.value_changed.emit(1)

                if self.flag: return True

        '''NOIZING'''
        if self.noized_chb.isChecked():
            for picture in glob.glob('{}/*.png'.format(path)):
                self.basename = os.path.basename(picture)
                self.filename = os.path.splitext(self.basename)[0]

                sign = cv2.imread(picture, cv2.IMREAD_UNCHANGED)
                if sign.shape[0] <= 70: continue

                noized = self.add_rain(sign,sign.shape[0]/20)
                try:
                    cv2.imwrite('{}/{}-noized.png'.format(path, self.filename), noized)
                except Exception as e:
                    ok = QtWidgets.QMessageBox.Abort
                    QtWidgets.QMessageBox.warning(self, 'Attention', str(e),ok)
                    return False

                self.pictures_iter += 1
                self.myWorker.value_changed.emit(1)

                if self.flag: return True

    def setFitWidth(self, value=True):
        if value:
            self.actions.fitWindow.setChecked(False)
        self.zoomMode = self.FIT_WIDTH if value else self.MANUAL_ZOOM
        self.adjustScale()

    def togglePolygons(self, value):
        for item, shape in self.labelList.itemsToShapes:
            item.setCheckState(Qt.Checked if value else Qt.Unchecked)

    def convertImageDataToPng(self, imageData):
        if imageData is None:
            return
        img = PIL.Image.open(io.BytesIO(imageData))
        with io.BytesIO() as imgBytesIO:
            img.save(imgBytesIO, "PNG")
            imgBytesIO.seek(0)
            data = imgBytesIO.read()
        return data

    def loadFile(self, filename=None):
        """Load the specified file, or the last opened file if None."""
        # changing fileListWidget loads file
        if (filename in self.imageList and
                self.fileListWidget.currentRow() !=
                self.imageList.index(filename)):
            self.fileListWidget.setCurrentRow(self.imageList.index(filename))
            self.fileListWidget.repaint()
            return

        self.resetState()
        self.canvas.setEnabled(False)
        if filename is None:
            filename = self.settings.value('filename', '')
        filename = str(filename)
        if not QtCore.QFile.exists(filename):
            self.errorMessage(
                'Error opening file', 'No such file: <b>%s</b>' % filename)
            return False
        # assumes same name, but json extension
        self.status("Loading %s..." % osp.basename(str(filename)))
        label_file = osp.splitext(filename)[0] + '.json'
        if self.output_dir:
            label_file = osp.join(self.output_dir, label_file)
        if QtCore.QFile.exists(label_file) and \
                LabelFile.isLabelFile(label_file):
            try:
                self.labelFile = LabelFile(label_file)
                # FIXME: PyQt4 installed via Anaconda fails to load JPEG
                # and JSON encoded images.
                # https://github.com/ContinuumIO/anaconda-issues/issues/131
                if QtGui.QImage.fromData(self.labelFile.imageData).isNull():
                    # tries to read image with PIL and convert it to PNG
                    self.labelFile.imageData = self.convertImageDataToPng(
                        self.labelFile.imageData)
                if QtGui.QImage.fromData(self.labelFile.imageData).isNull():
                    raise LabelFileError(
                        'Failed loading image data from label file.\n'
                        'Maybe this is a known issue of PyQt4 built on'
                        ' Anaconda, and may be fixed by installing PyQt5.')
            except LabelFileError as e:
                self.errorMessage(
                    'Error opening file',
                    "<p><b>%s</b></p>"
                    "<p>Make sure <i>%s</i> is a valid label file."
                    % (e, label_file))
                self.status("Error reading %s" % label_file)
                return False
            self.imageData = self.labelFile.imageData
            self.imagePath = osp.join(
                osp.dirname(label_file),
                self.labelFile.imagePath,
            )
            self.lineColor = QtGui.QColor(*self.labelFile.lineColor)
            self.fillColor = QtGui.QColor(*self.labelFile.fillColor)
            self.otherData = self.labelFile.otherData
        else:
            # Load image:
            # read data first and store for saving into label file.
            self.imageData = read(filename, None)
            if self.imageData is not None:
                # the filename is image not JSON
                self.imagePath = filename
                if QtGui.QImage.fromData(self.imageData).isNull():
                    self.imageData = self.convertImageDataToPng(self.imageData)
            self.labelFile = None
        image = QtGui.QImage.fromData(self.imageData)
        if image.isNull():
            formats = ['*.{}'.format(fmt.data().decode())
                       for fmt in QtGui.QImageReader.supportedImageFormats()]
            self.errorMessage(
                'Error opening file',
                '<p>Make sure <i>{0}</i> is a valid image file.<br/>'
                'Supported image formats: {1}</p>'
                .format(filename, ','.join(formats)))
            self.status("Error reading %s" % filename)
            return False
        self.image = image
        self.filename = filename
        if self._config['keep_prev']:
            prev_shapes = self.canvas.shapes

        self.canvas.loadPixmap(QtGui.QPixmap.fromImage(image))
        if self._config['flags']:
            self.loadFlags({k: False for k in self._config['flags']})
        if self._config['keep_prev']:
            self.loadShapes(prev_shapes)
        if self.labelFile:
            self.loadLabels(self.labelFile.shapes)
            if self.labelFile.flags is not None:
                self.loadFlags(self.labelFile.flags)
        self.setClean()
        self.canvas.setEnabled(True)
        self.adjustScale(initial=False)
        self.paintCanvas()
        self.addRecentFile(self.filename)
        self.toggleActions(True)
        self.status("Loaded %s" % osp.basename(str(filename)))
        return True

    def resizeEvent(self, event):
        if self.canvas and not self.image.isNull()\
           and self.zoomMode != self.MANUAL_ZOOM:
            self.adjustScale()
        super(MainWindow, self).resizeEvent(event)

    def paintCanvas(self):
        assert not self.image.isNull(), "cannot paint null image"
        self.canvas.scale = 0.01 * self.zoomWidget.value()
        self.canvas.adjustSize()
        self.canvas.update()

    def adjustScale(self, initial=False):
        value = self.scalers[self.FIT_WINDOW if initial else self.zoomMode]()
        self.zoomWidget.setValue(int(100 * value))

    def scaleFitWindow(self):
        """Figure out the size of the pixmap to fit the main widget."""
        e = 2.0  # So that no scrollbars are generated.
        w1 = self.centralWidget().width() - e
        h1 = self.centralWidget().height() - e
        a1 = w1 / h1
        # Calculate a new scale value based on the pixmap's aspect ratio.
        w2 = self.canvas.pixmap.width() - 0.0
        h2 = self.canvas.pixmap.height() - 0.0
        a2 = w2 / h2
        return w1 / w2 if a2 >= a1 else h1 / h2

    def scaleFitWidth(self):
        # The epsilon does not seem to work too well here.
        w = self.centralWidget().width() - 2.0
        return w / self.canvas.pixmap.width()

    def closeEvent(self, event):
        if not self.mayContinue():
            event.ignore()
        self.settings.setValue(
            'filename', self.filename if self.filename else '')
        self.settings.setValue('window/size', self.size())
        self.settings.setValue('window/position', self.pos())
        self.settings.setValue('window/state', self.saveState())
        self.settings.setValue('line/color', self.lineColor)
        self.settings.setValue('fill/color', self.fillColor)
        self.settings.setValue('recentFiles', self.recentFiles)

        self.settings.setValue("leftP", self.l_dist_spin.value())
        self.settings.setValue("rightP", self.r_dist_spin.value())
        self.settings.setValue("botP", self.b_dist_spin.value())

        self.settings.setValue("minAngle", self.min_angle_spin.value())
        self.settings.setValue("maxAngle", self.max_angle_spin.value())


        self.settings.setValue("minSize", self.min_size_spin.value())
        self.settings.setValue("maxSize", self.max_size_spin.value())


        self.settings.setValue("brightness", self.brightness_spin.value())
        self.settings.setValue("contrast", self.contrast_spin.value())
        self.settings.setValue("kernelSize", self.kernel_size_spin.value())

        self.settings.setValue("noized", self.noized_chb.isChecked())
        self.settings.setValue("flared", self.flared_chb.isChecked())

    # User Dialogs #

    def loadRecent(self, filename):
        if self.mayContinue():
            self.loadFile(filename)

    def openPrevImg(self, _value=False):
        keep_prev = self._config['keep_prev']
        if QtGui.QGuiApplication.keyboardModifiers() == \
                (QtCore.Qt.ControlModifier | QtCore.Qt.ShiftModifier):
            self._config['keep_prev'] = True

        if not self.mayContinue():
            return

        if len(self.imageList) <= 0:
            return

        if self.filename is None:
            return

        currIndex = self.imageList.index(self.filename)
        if currIndex - 1 >= 0:
            filename = self.imageList[currIndex - 1]
            if filename:
                self.loadFile(filename)

        self._config['keep_prev'] = keep_prev

    def openNextImg(self, _value=False, load=True):
        keep_prev = self._config['keep_prev']
        if QtGui.QGuiApplication.keyboardModifiers() == \
                (QtCore.Qt.ControlModifier | QtCore.Qt.ShiftModifier):
            self._config['keep_prev'] = True

        if not self.mayContinue():
            return

        if len(self.imageList) <= 0:
            return

        filename = None
        if self.filename is None:
            filename = self.imageList[0]
        else:
            currIndex = self.imageList.index(self.filename)
            if currIndex + 1 < len(self.imageList):
                filename = self.imageList[currIndex + 1]
            else:
                filename = self.imageList[-1]
        self.filename = filename

        if self.filename and load:
            self.loadFile(self.filename)

        self._config['keep_prev'] = keep_prev

    def openFile(self, _value=False):
        if not self.mayContinue():
            return
        path = osp.dirname(str(self.filename)) if self.filename else '.'
        formats = ['*.{}'.format(fmt.data().decode())
                   for fmt in QtGui.QImageReader.supportedImageFormats()]
        filters = "Image & Label files (%s)" % ' '.join(
            formats + ['*%s' % LabelFile.suffix])
        filename = QtWidgets.QFileDialog.getOpenFileName(
            self, '%s - Choose Image or Label file' % __appname__,
            path, filters)
        if QT5:
            filename, _ = filename
        filename = str(filename)
        if filename:
            self.loadFile(filename)

    def changeOutputDirDialog(self, _value=False):
        default_output_dir = self.output_dir
        if default_output_dir is None and self.filename:
            default_output_dir = osp.dirname(self.filename)
        if default_output_dir is None:
            default_output_dir = self.currentPath()

        output_dir = QtWidgets.QFileDialog.getExistingDirectory(
            self, '%s - Save/Load Annotations in Directory' % __appname__,
            default_output_dir,
            QtWidgets.QFileDialog.ShowDirsOnly |
            QtWidgets.QFileDialog.DontResolveSymlinks,
        )
        output_dir = str(output_dir)

        if not output_dir:
            return

        self.output_dir = output_dir

        self.statusBar().showMessage(
            '%s . Annotations will be saved/loaded in %s' %
            ('Change Annotations Dir', self.output_dir))
        self.statusBar().show()

        current_filename = self.filename
        self.importDirImages(self.lastOpenDir, load=False)

        if current_filename in self.imageList:
            # retain currently selected file
            self.fileListWidget.setCurrentRow(
                self.imageList.index(current_filename))
            self.fileListWidget.repaint()

    def saveFile(self, _value=False):
        assert not self.image.isNull(), "cannot save empty image"
        if self._config['flags'] or self.hasLabels():
            if self.labelFile:
                # DL20180323 - overwrite when in directory
                self._saveFile(self.labelFile.filename)
            elif self.output_file:
                self._saveFile(self.output_file)
                self.close()
            else:
                self._saveFile(self.saveFileDialog())

    def saveFileAs(self, _value=False):
        assert not self.image.isNull(), "cannot save empty image"
        if self.hasLabels():
            self._saveFile(self.saveFileDialog())

    def saveFileDialog(self):
        caption = '%s - Choose File' % __appname__
        filters = 'Label files (*%s)' % LabelFile.suffix
        if self.output_dir:
            dlg = QtWidgets.QFileDialog(
                self, caption, self.output_dir, filters
            )
        else:
            dlg = QtWidgets.QFileDialog(
                self, caption, self.currentPath(), filters
            )
        dlg.setDefaultSuffix(LabelFile.suffix[1:])
        dlg.setAcceptMode(QtWidgets.QFileDialog.AcceptSave)
        dlg.setOption(QtWidgets.QFileDialog.DontConfirmOverwrite, False)
        dlg.setOption(QtWidgets.QFileDialog.DontUseNativeDialog, False)
        basename = osp.splitext(self.filename)[0]
        if self.output_dir:
            default_labelfile_name = osp.join(
                self.output_dir, basename + LabelFile.suffix
            )
        else:
            default_labelfile_name = osp.join(
                self.currentPath(), basename + LabelFile.suffix
            )
        filename = dlg.getSaveFileName(
            self, 'Choose File', default_labelfile_name,
            'Label files (*%s)' % LabelFile.suffix)
        if QT5:
            filename, _ = filename
        filename = str(filename)
        return filename

    def _saveFile(self, filename):
        if filename and self.saveLabels(filename):
            self.addRecentFile(filename)
            self.setClean()

    def closeFile(self, _value=False):
        if not self.mayContinue():
            return
        self.resetState()
        self.setClean()
        self.toggleActions(False)
        self.canvas.setEnabled(False)
        self.actions.saveAs.setEnabled(False)

    # Message Dialogs. #
    def hasLabels(self):
        if not self.labelList.itemsToxShapes:
            self.errorMessage(
                'No objects labeled',
                'You must label at least one object to save the file.')
            return False
        return True

    def mayContinue(self):
        if not self.dirty:
            return True
        mb = QtWidgets.QMessageBox
        msg = 'Save annotations to "{}" before closing?'.format(self.filename)
        answer = mb.question(self,
                             'Save annotations?',
                             msg,
                             mb.Save | mb.Discard | mb.Cancel,
                             mb.Save)
        if answer == mb.Discard:
            return True
        elif answer == mb.Save:
            self.saveFile()
            return True
        else:  # answer == mb.Cancel
            return False

    def errorMessage(self, title, message):
        return QtWidgets.QMessageBox.critical(
            self, title, '<p><b>%s</b></p>%s' % (title, message))

    def currentPath(self):
        return osp.dirname(str(self.filename)) if self.filename else '.'

    def chooseColor1(self):
        color = self.colorDialog.getColor(
            self.lineColor, 'Choose line color', default=DEFAULT_LINE_COLOR)
        if color:
            self.lineColor = color
            # Change the color for all shape lines:
            Shape.line_color = self.lineColor
            self.canvas.update()
            self.setDirty()

    def chooseColor2(self):
        color = self.colorDialog.getColor(
            self.fillColor, 'Choose fill color', default=DEFAULT_FILL_COLOR)
        if color:
            self.fillColor = color
            Shape.fill_color = self.fillColor
            self.canvas.update()
            self.setDirty()

    def toggleKeepPrevMode(self):
        self._config['keep_prev'] = not self._config['keep_prev']

    def deleteSelectedShape(self):
        yes, no = QtWidgets.QMessageBox.Yes, QtWidgets.QMessageBox.No
        msg = 'You are about to permanently delete this polygon, ' \
              'proceed anyway?'
        if yes == QtWidgets.QMessageBox.warning(self, 'Attention', msg,
                                                yes | no):
            self.remLabel(self.canvas.deleteSelected())
            self.setDirty()
            if self.noShapes():
                for action in self.actions.onShapesPresent:
                    action.setEnabled(False)

    def chshapeLineColor(self):
        color = self.colorDialog.getColor(
            self.lineColor, 'Choose line color', default=DEFAULT_LINE_COLOR)
        if color:
            self.canvas.selectedShape.line_color = color
            self.canvas.update()
            self.setDirty()

    def chshapeFillColor(self):
        color = self.colorDialog.getColor(
            self.fillColor, 'Choose fill color', default=DEFAULT_FILL_COLOR)
        if color:
            self.canvas.selectedShape.fill_color = color
            self.canvas.update()
            self.setDirty()

    def copyShape(self):
        self.canvas.endMove(copy=True)
        self.addLabel(self.canvas.selectedShape)
        self.setDirty()

    def moveShape(self):
        self.canvas.endMove(copy=False)
        self.setDirty()

    def openDirDialog(self, _value=False, dirpath=None):
        if not self.mayContinue():
            return

        defaultOpenDirPath = dirpath if dirpath else '.'
        if self.lastOpenDir and osp.exists(self.lastOpenDir):
            defaultOpenDirPath = self.lastOpenDir
        else:
            defaultOpenDirPath = osp.dirname(self.filename) \
                if self.filename else '.'

        targetDirPath = str(QtWidgets.QFileDialog.getExistingDirectory(
            self, '%s - Open Directory' % __appname__, defaultOpenDirPath,
            QtWidgets.QFileDialog.ShowDirsOnly |
            QtWidgets.QFileDialog.DontResolveSymlinks))
        if not targetDirPath: return
        self.importDirImages(targetDirPath)

    @property
    def imageList(self):
        lst = []
        for i in range(self.fileListWidget.count()):
            item = self.fileListWidget.item(i)
            lst.append(item.text())
        return lst

    @property
    def processedImageList(self):
        lst = []
        for i in range(self.fileListWidgetP.count()):
            item = self.fileListWidgetP.item(i)
            lst.append(item.text())
        return lst

    def importDirImages(self, dirpath, pattern=None, load=True):
        self.actions.openNextImg.setEnabled(True)
        self.actions.openPrevImg.setEnabled(True)
        # self.actions.remove_sample.setEnabled(True)
        self.actions.generation_settings.setEnabled(True)

        if not self.mayContinue() or not dirpath:
            return

        self.lastOpenDir = dirpath
        self.filename = None
        self.fileListWidget.clear()
        for filename in self.scanAllImages(dirpath):
            if pattern and pattern not in filename:
                continue
            label_file = osp.splitext(filename)[0] + '.json'
            if self.output_dir:
                label_file = osp.join(self.output_dir, label_file)
            item = QtWidgets.QListWidgetItem(filename)
            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            if QtCore.QFile.exists(label_file) and \
                    LabelFile.isLabelFile(label_file):
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)
            self.fileListWidget.addItem(item)
        self.openNextImg(load=load)


    def result_pictset_fileListWidget(self, dirpath=os.getcwd() + "/result/signs", pattern=None):
        if not self.mayContinue() or not dirpath:
            return

        self.filename = None
        self.fileListWidgetP.clear()
        for filename in self.scanAllImages(dirpath):
            if pattern and pattern not in filename:
                continue
            label_file = osp.splitext(filename)[0] + '.json'
            if self.output_dir:
                label_file = osp.join(self.output_dir, label_file)
            item = QtWidgets.QListWidgetItem(filename)
            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            if QtCore.QFile.exists(label_file) and \
                    LabelFile.isLabelFile(label_file):
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)
            self.fileListWidgetP.addItem(item)
        self.fileSearchP.setPlaceholderText('Search Filename out of {} picts'.format(len(os.listdir(dirpath))))
        self.actions.remove_sample.setEnabled(True)


    def scanAllImages(self, folderPath):
        extensions = ['.%s' % fmt.data().decode("ascii").lower()
                      for fmt in QtGui.QImageReader.supportedImageFormats()]
        images = []

        for root, dirs, files in os.walk(folderPath):
            for file in files:
                if file.lower().endswith(tuple(extensions)):
                    relativePath = osp.join(root, file)
                    images.append(relativePath)
            '''BREAK - TO READ THE EXACT (ONE LEVEL) FOLDER WE SPECIFIED'''
            break
        images.sort(key=lambda x: x.lower())
        return images


def read(filename, default=None):
    try:
        with open(filename, 'rb') as f:
            return f.read()
    except Exception:
        return default


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
USAGE
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Run 'main.py' in PyCharm IDE.

While run click 'Open Dir' to open the directory with prepared signs. All signs from the directory will be loaded to 'Original File List' widget. Simultaneously 'Settings' button from the toolbar will be enabled.  

Once settings opened and you satisfied with configured values for appropriate widgets it's possible to preview all the effects via 'Preview' button.  

Clicking 'Generate' button will launch the sign generation process with opening modal progress bar. After signs generation completed both 'Remove Selected' and 'Create Samples' buttons will be enabled.

Generated signs will be listed in adjacent 'Procceced File List' tab. It's possible to delete some of the generated signs via 'Remove Selected' button.

Once 'Create Samples' button clicked 2 popup dialog  windows will appear:
	- first one will ask you to specify folder with generated signs;
	- second one to specify the backgroud overlays.

'VOC/YOLO' button serves for switching beetween respective annotation formats.
'Change annotattion' button - to replace paths in VOC-like annotation files.
	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PROGRAMM STRUCTURE
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Main part pf the programm is located in the 'app.py' file.
'canvas.py' - class of central widget, which is responsible for all the painting. 

Initially get them from whatever you want.

All result data is stored in 'result' directory, where: 
	- signs 	- directory to store artificially generated signs;
	- images 	- directory to store ready for training dataset;
	- yolo_coefs 	- directory to store annotation files in yolo format;
	- voc_coefs	- directory to store annotation files in voc format.

Requirement to initial signs name:
second and third characted specify class id of the signs. Example:
	z01_1111.png - class id would be '01'.
	 ||
	 id

All shortcats and visibility settings are located in the 'default_config.yaml' file.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
BUGS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In some cases total number of generated signs may differ from the one depicted by 'Total pictures to generate:' string due to some exeptions in generation algorythm.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
TIPS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

While working in PyCharmIDE go to the 'File->Settings->Project:$project_name->Project structure->Exclude files:' and put '*.png' there. It's strongly recommended due to the fact PyCharm tries to update all the project structure after launching. This will save much of your time and lagging.
